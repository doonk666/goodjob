import App from './App'

// #ifndef VUE3
import Vue from 'vue'
import './uni.promisify.adaptor'
Vue.config.productionTip = false
App.mpType = 'app'

// Vue2 路由守卫（使用 uni-app 原生路由钩子）
uni.addInterceptor('navigateTo', {
  invoke(options) {
    // 校验是否需要登录（排除登录页）
    if (!options.url.includes('/pages/login/login') && !uni.getStorageSync('userInfo')) {
      // 未登录，拦截跳转并跳转到登录页
      uni.redirectTo({ url: '/pages/login/login?redirect=' + encodeURIComponent(options.url) });
      return false; // 阻止原跳转
    }
    return true;
  }
});

// 拦截其他路由跳转方式（确保所有跳转都经过登录校验）
['redirectTo', 'switchTab', 'reLaunch', 'navigateBack'].forEach(method => {
  uni.addInterceptor(method, {
    invoke(options) {
      // 排除登录页和返回操作
      const isLoginPage = options.url?.includes('/pages/login/login') || method === 'navigateBack';
      if (!isLoginPage && !uni.getStorageSync('userInfo')) {
        uni.redirectTo({ url: '/pages/login/login' });
        return false;
      }
      return true;
    }
  });
});

const app = new Vue({
  ...App
})
app.$mount()
// #endif

// #ifdef VUE3
import { createSSRApp } from 'vue'

// Vue3 改用 uni-app 原生路由钩子（替代 vue-router，解决 Vite 动态导入警告）
// 拦截 navigateTo（普通跳转）
uni.addInterceptor('navigateTo', {
  invoke(options) {
    // 排除登录页，未登录则拦截
    if (!options.url.includes('/pages/login/login') && !uni.getStorageSync('userInfo')) {
      uni.redirectTo({ 
        url: `/pages/login/login?redirect=${encodeURIComponent(options.url)}` 
      });
      return false; // 阻止原跳转
    }
    return true;
  }
});

// 拦截 redirectTo（关闭当前页跳转）
uni.addInterceptor('redirectTo', {
  invoke(options) {
    if (!options.url.includes('/pages/login/login') && !uni.getStorageSync('userInfo')) {
      uni.redirectTo({ url: '/pages/login/login' });
      return false;
    }
    return true;
  }
});

// 拦截 switchTab（tabBar 跳转）
uni.addInterceptor('switchTab', {
  invoke(options) {
    if (!uni.getStorageSync('userInfo')) {
      uni.redirectTo({ url: '/pages/login/login' });
      return false;
    }
    return true;
  }
});

// 拦截 reLaunch（重启应用跳转）
uni.addInterceptor('reLaunch', {
  invoke(options) {
    if (!options.url.includes('/pages/login/login') && !uni.getStorageSync('userInfo')) {
      uni.redirectTo({ url: '/pages/login/login' });
      return false;
    }
    return true;
  }
});

export function createApp() {
  const app = createSSRApp(App)
  return {
    app
  }
}
// #endif