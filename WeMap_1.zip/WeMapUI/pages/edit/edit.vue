<template>
  <view class="note-edit-page">
    <!-- 顶部导航栏 -->
    <view class="nav-bar">
      <view class="back-btn" @click="navigateBack">
        <uni-icons type="back" size="28" color="#333"></uni-icons>
      </view>
      <view class="nav-title">写景点笔记</view>
      <view class="empty-container"></view>
    </view>

    <!-- 表单内容区域 -->
    <form class="note-form">
      <!-- 标题输入 -->
      <view class="form-item">
        <text class="label required">标题</text>
        <input
          class="input"
          v-model="noteForm.title"
          placeholder="输入笔记标题（例如：野鸭湖游玩攻略）"
          placeholder-style="color:#999"
        />
      </view>

      <!-- 标签选择 -->
      <view class="form-item">
        <text class="label">标签</text>
        <view class="tags-container">
          <view class="tag-item" v-for="(tag, index) in noteForm.tags" :key="index">
            <text class="tag-text">{{ tag }}</text>
            <uni-icons 
              type="close" 
              size="18" 
              color="#d48806" 
              class="tag-delete"
              @click.stop="deleteTag(index)"
            ></uni-icons>
          </view>
          
          <input
            v-if="noteForm.tags.length < 5"
            class="tag-input"
            v-model="newTag"
            placeholder="输入标签，按回车添加"
            placeholder-style="color:#999"
            @confirm="addTag"
          />
          
          <text class="tag-tip" v-if="noteForm.tags.length >= 5">最多添加5个标签</text>
        </view>
        <text class="tag-desc">添加相关标签，让笔记更容易被发现（例如：自然风光、亲子游、拍照打卡）</text>
      </view>

      <!-- 图片上传 -->
      <view class="form-item">
        <text class="label required">图片</text>
        <view class="image-upload">
          <view class="image-item" v-for="(img, index) in noteForm.images" :key="index">
            <image :src="img" mode="aspectFill"></image>
            <view class="delete-img" @click="deleteImage(index)">
              <uni-icons type="close" size="20" color="#fff"></uni-icons>
            </view>
          </view>
          <view class="upload-btn" @click="chooseImage" v-if="noteForm.images.length < 5">
            <uni-icons type="camera" size="36" color="#ffa500"></uni-icons>
            <text class="upload-text">上传图片</text>
          </view>
          <text class="image-tip">最多上传5张图片</text>
        </view>
      </view>

      <!-- 描述文字 -->
      <view class="form-item">
        <text class="label required">描述</text>
        <textarea
          class="textarea"
          v-model="noteForm.description"
          placeholder="分享你的游玩体验、攻略或感受..."
          placeholder-style="color:#999"
          auto-height
          maxlength="500"
        ></textarea>
        <text class="word-count">{{ noteForm.description.length }}/500</text>
      </view>

      <!-- 坐标信息 -->
      <view class="form-item">
        <text class="label">坐标</text>
        <view class="location-info">
          <uni-icons type="location" size="24" color="#ffa500"></uni-icons>
          <text class="location-text">
            {{ noteForm.longitude ? `${noteForm.longitude.toFixed(6)}, ${noteForm.latitude.toFixed(6)}` : '获取中...' }}
          </text>
        </view>
        <text class="location-tip">当前景点坐标，不可修改</text>
      </view>
    </form>

    <!-- 发布按钮 -->
    <view class="submit-bar">
      <button class="submit-btn" @click="publishNote" :disabled="isSubmitDisabled">
        发布笔记
      </button>
    </view>
  </view>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();

// 初始化表单数据
const INIT_FORM = {
  title: '', // 标题
  tags: [], // 标签列表
  images: [], // 上传图片列表（临时路径）
  description: '', // 描述文字
  longitude: 100.123456, // 经度
  latitude: 30.654321 // 纬度
};

const noteForm = ref({ ...INIT_FORM });
const newTag = ref('');

// ========== 接口相关注释开始 ==========

/**
 * 页面挂载生命周期
 * TODO: 需要对接的接口：
 * 1. 获取用户定位信息接口 - 替换当前的模拟坐标数据
 * 2. 如果有编辑模式，需要获取笔记详情接口
 */
onMounted(() => {
  // 深拷贝初始值，彻底重置表单
  noteForm.value = JSON.parse(JSON.stringify(INIT_FORM));
  newTag.value = '';
  
  // 获取首页传递的坐标（如果有）
  const routeParams = router.currentRoute.value.query;
  if (routeParams.longitude && routeParams.latitude) {
    noteForm.value.longitude = parseFloat(routeParams.longitude);
    noteForm.value.latitude = parseFloat(routeParams.latitude);
  } else {
    // TODO: 调用获取用户当前位置接口
    // 示例：getUserLocation().then(location => {
    //   noteForm.value.longitude = location.longitude;
    //   noteForm.value.latitude = location.latitude;
    // });
  }
  
  // TODO: 如果是编辑模式，需要调用获取笔记详情接口
  // 示例：if (routeParams.noteId) {
  //   getNoteDetail(routeParams.noteId).then(detail => {
  //     noteForm.value = { ...detail };
  //   });
  // }
});

/**
 * 图片上传功能
 * TODO: 需要对接的接口：
 * 1. 图片上传接口 - 将临时路径转换为服务器存储路径
 * 2. 图片压缩处理接口（可选）
 */
const chooseImage = () => {
  uni.chooseImage({
    count: 5 - noteForm.value.images.length,
    sizeType: ['original', 'compressed'],
    sourceType: ['album', 'camera'],
    success: (res) => {
      // 这里获取的是临时路径，需要上传到服务器
      const tempFilePaths = res.tempFilePaths;
      
      // TODO: 调用图片上传接口，将临时路径转换为服务器URL
      // 示例：
      // uploadImages(tempFilePaths).then(serverUrls => {
      //   noteForm.value.images = [...noteForm.value.images, ...serverUrls];
      // }).catch(err => {
      //   uni.showToast({ title: '图片上传失败', icon: 'none' });
      // });
      
      // 临时方案：直接使用临时路径（发布时需要替换为服务器URL）
      noteForm.value.images = [...noteForm.value.images, ...tempFilePaths];
    }
  });
};

/**
 * 发布笔记功能
 * TODO: 需要对接的核心接口：
 * 1. 发布笔记接口 - 将表单数据提交到服务器
 * 2. 数据验证接口（可选）
 * 3. 敏感词过滤接口（可选）
 */
const publishNote = () => {
  // 表单验证
  if (!noteForm.value.title.trim()) {
    uni.showToast({ title: '请输入笔记标题', icon: 'none' });
    return;
  }
  if (noteForm.value.images.length === 0) {
    uni.showToast({ title: '请至少上传1张图片', icon: 'none' });
    return;
  }
  if (!noteForm.value.description.trim()) {
    uni.showToast({ title: '请输入游玩描述', icon: 'none' });
    return;
  }

  // 构建提交数据
  const submitData = {
    title: noteForm.value.title.trim(),
    tags: noteForm.value.tags,
    images: noteForm.value.images, // TODO: 需要确保这里是服务器URL，不是临时路径
    description: noteForm.value.description.trim(),
    longitude: noteForm.value.longitude,
    latitude: noteForm.value.latitude,
    createTime: new Date().getTime(),
    // TODO: 可能需要添加的用户信息
    // userId: getUserId(),
    // userName: getUserInfo().name,
  };

  // TODO: 调用发布笔记接口
  // 示例接口调用：
  uni.showLoading({ title: '发布中...' });
  
  // 模拟接口调用 - 实际开发时需要替换为真实接口
  setTimeout(() => {
    // 真实接口调用示例：
    // publishNoteApi(submitData).then(res => {
    //   uni.hideLoading();
    //   if (res.code === 200) {
    //     uni.showToast({ title: '笔记发布成功', icon: 'success' });
    //     resetForm();
    //     setTimeout(() => {
    //       router.push('/pages/index/index');
    //     }, 1500);
    //   } else {
    //     uni.showToast({ title: res.message || '发布失败', icon: 'none' });
    //   }
    // }).catch(err => {
    //   uni.hideLoading();
    //   uni.showToast({ title: '网络错误，请重试', icon: 'none' });
    // });
    
    // 当前模拟成功
    uni.hideLoading();
    uni.showToast({
      title: '笔记发布成功',
      icon: 'success',
      duration: 1500
    });

    // 发布成功后重置表单
    resetForm();

    // 延迟返回首页
    setTimeout(() => {
      router.push('/pages/index/index');
    }, 1500);
  }, 1000);
};

/**
 * 其他可能需要对接的接口：
 * 1. 获取标签推荐接口 - 可以根据标题自动推荐相关标签
 * 2. 图片识别接口 - 自动识别图片内容并生成标签
 * 3. 位置详情接口 - 根据坐标获取具体位置名称
 * 4. 草稿保存接口 - 自动保存草稿功能
 */

// ========== 接口相关注释结束 ==========

// 提交按钮禁用状态
const isSubmitDisabled = computed(() => {
  return !noteForm.value.title.trim() || 
         !noteForm.value.description.trim() || 
         noteForm.value.images.length === 0;
});

// 返回上一页
const navigateBack = () => {
  resetForm();
  router.back();
};

// 重置表单
const resetForm = () => {
  noteForm.value = JSON.parse(JSON.stringify(INIT_FORM));
  newTag.value = '';
};

// 添加标签
const addTag = () => {
  const tag = newTag.value.trim();
  if (!tag) {
    uni.showToast({ title: '标签不能为空', icon: 'none', duration: 1000 });
    return;
  }
  if (noteForm.value.tags.includes(tag)) {
    uni.showToast({ title: '该标签已添加', icon: 'none', duration: 1000 });
    newTag.value = '';
    return;
  }
  if (noteForm.value.tags.length >= 5) {
    uni.showToast({ title: '最多添加5个标签', icon: 'none', duration: 1000 });
    return;
  }
  noteForm.value.tags.push(tag);
  newTag.value = '';
};

// 删除标签
const deleteTag = (index) => {
  noteForm.value.tags.splice(index, 1);
};

// 删除图片
const deleteImage = (index) => {
  noteForm.value.images.splice(index, 1);
};
</script>

<style lang="scss" scoped>
.note-edit-page {
  min-height: 100vh;
  background-color: #fff;
  padding-bottom: 120rpx;
}

.nav-bar {
  width: 100%;
  height: 88rpx;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 30rpx;
  border-bottom: 1rpx solid #f5f5f5;
  box-sizing: border-box;
  position: fixed;
  top: 0;
  left: 0;
  background-color: #fff;
  z-index: 99;
}

.nav-bar .back-btn {
  width: 40rpx;
  height: 40rpx;
  display: flex;
  align-items: center;
  justify-content: center;
}

.nav-bar .nav-title {
  font-size: 32rpx;
  font-weight: 600;
  color: #333;
  flex: 1;
  text-align: center;
}

.nav-bar .empty-container {
  width: 40rpx;
  height: 40rpx;
}

.note-form {
  margin-top: 108rpx;
  padding: 0 30rpx;
}

.form-item {
  margin-bottom: 40rpx;
}

.form-item .label {
  display: block;
  font-size: 28rpx;
  color: #333;
  margin-bottom: 12rpx;
  font-weight: 500;
  padding: 0 10rpx;
}

.form-item .required::after {
  content: '*';
  color: #ff6b6b;
  margin-left: 4rpx;
}

.form-item .input {
  width: 100%;
  height: 72rpx;
  border: 1rpx solid #f0e6d2;
  border-radius: 12rpx;
  padding: 0 20rpx;
  font-size: 28rpx;
  color: #333;
  box-sizing: border-box;
  background-color: #fffaf0;
  margin: 0 10rpx;
}

.tags-container {
  display: flex;
  flex-wrap: wrap;
  gap: 16rpx;
  margin-bottom: 12rpx;
  padding: 0 10rpx;
}

.tags-container .tag-item {
  display: flex;
  align-items: center;
  background-color: #fff8dc;
  color: #ffa500;
  padding: 8rpx 20rpx;
  border-radius: 30rpx;
  font-size: 26rpx;
  gap: 8rpx;
  border: 1rpx solid #ffe4b5;
}

.tags-container .tag-item .tag-delete {
  cursor: pointer;
}

.tags-container .tag-input {
  flex: 1;
  min-width: 120rpx;
  height: 64rpx;
  border: 1rpx solid #f0e6d2;
  border-radius: 32rpx;
  padding: 0 20rpx;
  font-size: 26rpx;
  color: #333;
  box-sizing: border-box;
  background-color: #fffaf0;
  margin: 0 10rpx;
}

.tags-container .tag-tip {
  font-size: 22rpx;
  color: #999;
  align-self: center;
  margin: 0 10rpx;
}

.tag-desc {
  font-size: 22rpx;
  color: #777;
  line-height: 1.4;
  padding: 0 10rpx;
}

.image-upload {
  overflow: hidden;
  padding: 0 10rpx;
}

.image-upload .image-item {
  width: 160rpx;
  height: 160rpx;
  border-radius: 12rpx;
  overflow: hidden;
  position: relative;
  float: left;
  margin-right: 20rpx;
  margin-bottom: 20rpx;
  border: 1rpx solid #ffe4b5;
}

.image-upload .image-item image {
  width: 100%;
  height: 100%;
}

.image-upload .image-item .delete-img {
  position: absolute;
  top: -10rpx;
  right: -10rpx;
  width: 36rpx;
  height: 36rpx;
  background-color: rgba(255, 165, 0, 0.7);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.image-upload .upload-btn {
  width: 160rpx;
  height: 160rpx;
  border: 1rpx dashed #ffa500;
  border-radius: 12rpx;
  float: left;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background-color: #fffaf0;
}

.image-upload .upload-btn .upload-text {
  font-size: 22rpx;
  color: #ffa500;
  margin-top: 12rpx;
}

.image-upload .image-tip {
  display: block;
  clear: both;
  font-size: 22rpx;
  color: #999;
  margin-top: 12rpx;
  padding: 0 10rpx;
}

.textarea {
  width: 100%;
  border: 1rpx solid #f0e6d2;
  border-radius: 12rpx;
  padding: 20rpx;
  font-size: 28rpx;
  color: #333;
  line-height: 1.6;
  box-sizing: border-box;
  min-height: 200rpx;
  background-color: #fffaf0;
  margin: 0 10rpx;
}

.word-count {
  display: block;
  text-align: right;
  font-size: 22rpx;
  color: #999;
  margin-top: 8rpx;
  padding: 0 10rpx;
}

.location-info {
  display: flex;
  align-items: center;
  padding: 20rpx;
  border: 1rpx solid #f0e6d2;
  border-radius: 12rpx;
  background-color: #fffaf0;
  margin: 0 10rpx;
}

.location-info .location-text {
  font-size: 26rpx;
  color: #666;
  margin-left: 12rpx;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.location-tip {
  display: block;
  font-size: 22rpx;
  color: #999;
  margin-top: 8rpx;
  padding: 0 10rpx;
}

.submit-bar {
  position: fixed;
  bottom: 0;
  left: 0;
  width: 100%;
  padding: 20rpx 30rpx;
  background-color: #fff;
  box-shadow: 0 -2rpx 10rpx rgba(255, 165, 0, 0.1);
  box-sizing: border-box;
}

.submit-bar .submit-btn {
  width: 100%;
  height: 88rpx;
  background-color: #ffa500;
  color: #fff;
  font-size: 32rpx;
  font-weight: 600;
  border-radius: 44rpx;
  border: none;
  display: flex;
  align-items: center;
  justify-content: center;
}

.submit-bar .submit-btn:disabled {
  background-color: #ffd591;
  color: #fff;
}
</style>