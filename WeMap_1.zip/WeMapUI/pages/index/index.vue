<template>
	<view class="HomeLayout pageBg">
		<!-- 轮播图区域 -->
		<view class="banner">
			<swiper circular indicator-dots indicator-color="rgba(255,255,255,0.5)" 
			indicator-active-color="#fff" autoplay>
				<swiper-item>
					<image src="/components/commom/images/海岛.jpg" mode="aspectFill"></image>
				</swiper-item>
				<swiper-item>
					<image src="/components/commom/images/塔楼.jpg" mode="aspectFill"></image>
				</swiper-item>
				<swiper-item>
					<image src="/components/commom/images/野鸭湖.jpg" mode="aspectFill"></image>
				</swiper-item>
			</swiper>
		</view>
		
		<!-- 公告区域 -->
		<view class="notice">
			<view class="left">
				<uni-icons type="sound-filled" size="20" color="#FFA500"></uni-icons>
				<text class="text">公告</text>
			</view>
			<view class="center">
				<swiper vertical autoplay interval="1500" duration="300" circular>
					<swiper-item>警告！野鸭湖鸭子泛滥！</swiper-item>
					<swiper-item>来看黑独山月球同款地貌！</swiper-item>
					<swiper-item>这里船真的能 "悬浮" 在水里！</swiper-item>
					<swiper-item>水杉林藏着夏天的清凉麻将局！</swiper-item>
				</swiper>
			</view>
			<view class="right">
				<uni-icons type="forward" size="16" color="#333"></uni-icons>
			</view>
		</view>
		
		<!-- 主地图区域 -->
		<view class="map-container">
			<!-- 高德地图容器 -->
			<div id="amap" class="we-map"></div>
			
			<!-- 发布笔记按钮 -->
			<view class="location-btn" @click="navigateToNotePage">
				<uni-icons type="plus" size="28" color="#fff"></uni-icons>
			</view>
		</view>
	</view>
</template>

<script setup>
import { ref, onMounted } from 'vue';

// 存储当前位置坐标
const currentLocation = ref({
  latitude: 39.9042, // 默认北京
  longitude: 116.4074
});

// 定位相关信息
const locationMethod = ref('未定位');
const coordinateSystem = ref('GCJ-02');
const coordinateConversion = ref('');

let h5map = null;
let geolocation = null;

onMounted(() => {
  // 初始化地图和定位
  initMap();
});

// 坐标转换工具类
class CoordinateTransform {
  static PI = 3.1415926535897932384626;
  static A = 6378245.0;
  static EE = 0.00669342162296594323;
  
  /**
   * WGS84转GCJ02(火星坐标系)
   */
  static wgs84ToGcj02(lng, lat) {
    if (this.outOfChina(lng, lat)) {
      return [lng, lat];
    }
    
    let dLat = this.transformLat(lng - 105.0, lat - 35.0);
    let dLng = this.transformLng(lng - 105.0, lat - 35.0);
    const radLat = lat / 180.0 * this.PI;
    let magic = Math.sin(radLat);
    magic = 1 - this.EE * magic * magic;
    const sqrtMagic = Math.sqrt(magic);
    dLat = (dLat * 180.0) / ((this.A * (1 - this.EE)) / (magic * sqrtMagic) * this.PI);
    dLng = (dLng * 180.0) / ((this.A / sqrtMagic) * Math.cos(radLat) * this.PI);
    
    const mgLat = lat + dLat;
    const mgLng = lng + dLng;
    
    return [mgLng, mgLat];
  }
  
  /**
   * GCJ02转WGS84
   */
  static gcj02ToWgs84(lng, lat) {
    if (this.outOfChina(lng, lat)) {
      return [lng, lat];
    }
    
    let dLat = this.transformLat(lng - 105.0, lat - 35.0);
    let dLng = this.transformLng(lng - 105.0, lat - 35.0);
    const radLat = lat / 180.0 * this.PI;
    let magic = Math.sin(radLat);
    magic = 1 - this.EE * magic * magic;
    const sqrtMagic = Math.sqrt(magic);
    dLat = (dLat * 180.0) / ((this.A * (1 - this.EE)) / (magic * sqrtMagic) * this.PI);
    dLng = (dLng * 180.0) / ((this.A / sqrtMagic) * Math.cos(radLat) * this.PI);
    
    const mgLat = lat + dLat;
    const mgLng = lng + dLng;
    
    return [lng * 2 - mgLng, lat * 2 - mgLat];
  }
  
  /**
   * 百度坐标系(BD09)转GCJ02(火星坐标系)
   */
  static bd09ToGcj02(bdLng, bdLat) {
    const x = bdLng - 0.0065;
    const y = bdLat - 0.006;
    const z = Math.sqrt(x * x + y * y) - 0.00002 * Math.sin(y * this.PI);
    const theta = Math.atan2(y, x) - 0.000003 * Math.cos(x * this.PI);
    const ggLng = z * Math.cos(theta);
    const ggLat = z * Math.sin(theta);
    return [ggLng, ggLat];
  }
  
  /**
   * GCJ02(火星坐标系)转百度坐标系(BD09)
   */
  static gcj02ToBd09(lng, lat) {
    const z = Math.sqrt(lng * lng + lat * lat) + 0.00002 * Math.sin(lat * this.PI);
    const theta = Math.atan2(lat, lng) + 0.000003 * Math.cos(lng * this.PI);
    const bdLng = z * Math.cos(theta) + 0.0065;
    const bdLat = z * Math.sin(theta) + 0.006;
    return [bdLng, bdLat];
  }
  
  /**
   * 判断是否在中国境内
   */
  static outOfChina(lng, lat) {
    if (lng < 72.004 || lng > 137.8347) {
      return true;
    }
    if (lat < 0.8293 || lat > 55.8271) {
      return true;
    }
    return false;
  }
  
  static transformLat(x, y) {
    let ret = -100.0 + 2.0 * x + 3.0 * y + 0.2 * y * y + 0.1 * x * y + 0.2 * Math.sqrt(Math.abs(x));
    ret += (20.0 * Math.sin(6.0 * x * this.PI) + 20.0 * Math.sin(2.0 * x * this.PI)) * 2.0 / 3.0;
    ret += (20.0 * Math.sin(y * this.PI) + 40.0 * Math.sin(y / 3.0 * this.PI)) * 2.0 / 3.0;
    ret += (160.0 * Math.sin(y / 12.0 * this.PI) + 320 * Math.sin(y * this.PI / 30.0)) * 2.0 / 3.0;
    return ret;
  }
  
  static transformLng(x, y) {
    let ret = 300.0 + x + 2.0 * y + 0.1 * x * x + 0.1 * x * y + 0.1 * Math.sqrt(Math.abs(x));
    ret += (20.0 * Math.sin(6.0 * x * this.PI) + 20.0 * Math.sin(2.0 * x * this.PI)) * 2.0 / 3.0;
    ret += (20.0 * Math.sin(x * this.PI) + 40.0 * Math.sin(x / 3.0 * this.PI)) * 2.0 / 3.0;
    ret += (150.0 * Math.sin(x / 12.0 * this.PI) + 300.0 * Math.sin(x / 30.0 * this.PI)) * 2.0 / 3.0;
    return ret;
  }
}

// 初始化地图
const initMap = () => {
  // 动态加载高德地图JS
  if (window.AMap) {
    createMap();
  } else {
    const script = document.createElement("script");
    script.src = "https://webapi.amap.com/maps?v=2.0&key=3b88de31f6799c6f2ce8ca20e7e82f3b&plugin=AMap.Geolocation,AMap.Geocoder";
    script.onload = createMap;
    document.head.appendChild(script);
  }
};

// 创建地图实例
const createMap = () => {
  console.log('创建地图，中心点:', currentLocation.value);
  
  h5map = new AMap.Map("amap", {
    zoom: 16,
    center: [currentLocation.value.longitude, currentLocation.value.latitude],
    viewMode: "3D",
    zoomControl: true,
    scaleControl: true,
    mapStyle: 'amap://styles/normal'
  });

  // 优先使用uni-app定位，然后转换为GCJ02坐标系
  useUnifiedLocation();
};

// 统一位置获取方法
const useUnifiedLocation = () => {
  // 首先尝试uni.getLocation获取WGS84坐标
  uni.getLocation({
    type: 'wgs84',
    isHighAccuracy: true,
    success: (res) => {
      console.log('uni定位成功(WGS84):', res);
      
      // 将WGS84坐标转换为GCJ02
      const [gcjLng, gcjLat] = CoordinateTransform.wgs84ToGcj02(res.longitude, res.latitude);
      
      // 更新当前位置
      currentLocation.value.latitude = gcjLat;
      currentLocation.value.longitude = gcjLng;
      
      locationMethod.value = 'uni定位(WGS84转GCJ02)';
      coordinateSystem.value = 'GCJ-02';
      coordinateConversion.value = 'WGS84→GCJ02';
      
      // 设置地图中心
      h5map.setCenter([gcjLng, gcjLat]);
      
      // 添加标记
      addMarkerToMap(gcjLng, gcjLat, '转换后位置');
      
      // 获取详细地址
      getPreciseAddress(gcjLng, gcjLat);
      
      uni.showToast({
        title: '定位成功',
        icon: 'success',
        duration: 2000
      });
      
      console.log('WGS84原始坐标:', res.longitude, res.latitude);
      console.log('GCJ02转换坐标:', gcjLng, gcjLat);
    },
    fail: (error) => {
      console.error('uni定位失败:', error);
      
      // uni定位失败，使用高德定位作为备选
      useAmapLocationAsFallback();
    }
  });
};

// 高德定位作为备选
const useAmapLocationAsFallback = () => {
  console.log('使用高德定位作为备选...');
  
  AMap.plugin(['AMap.Geolocation', 'AMap.Geocoder'], () => {
    geolocation = new AMap.Geolocation({
      enableHighAccuracy: true,
      timeout: 20000,
      showButton: true,
      buttonPosition: 'RB',
      buttonOffset: new AMap.Pixel(10, 80),
      showMarker: true,
      showCircle: true,
      panToLocation: true,
      zoomToAccuracy: true,
      extensions: 'all',
      convert: true,
      GeoLocationFirst: true,
      noIpLocate: 0,
      noGeoLocation: 0
    });

    h5map.addControl(geolocation);
    
    // 监听定位事件
    geolocation.on('complete', onAmapLocationSuccess);
    geolocation.on('error', onAmapLocationError);
    
    // 开始定位
    geolocation.getCurrentPosition();
  });
};

// 高德定位成功
const onAmapLocationSuccess = (result) => {
  console.log('高德定位成功:', result);
  
  // 高德返回的已经是GCJ02坐标，直接使用
  currentLocation.value.latitude = result.position.lat;
  currentLocation.value.longitude = result.position.lng;
  
  locationMethod.value = '高德定位';
  coordinateSystem.value = 'GCJ-02';
  coordinateConversion.value = '无转换(已是GCJ02)';
  
  // 添加标记
  addMarkerToMap(result.position.lng, result.position.lat, '高德定位位置');
  
  // 获取详细地址
  getPreciseAddress(result.position.lng, result.position.lat);
  
  uni.showToast({
    title: `高德定位成功`,
    icon: 'success',
    duration: 2000
  });
};

// 高德定位失败
const onAmapLocationError = (error) => {
  console.error('高德定位失败:', error);
  
  // 最终备选：IP定位
  useIPLocationAsFallback();
};

// IP定位作为最终备选
const useIPLocationAsFallback = () => {
  console.log('使用IP定位作为最终备选...');
  
  locationMethod.value = 'IP定位';
  coordinateConversion.value = '';
  
  // 使用高德IP定位API
  fetch(`https://restapi.amap.com/v3/ip?key=3b88de31f6799c6f2ce8ca20e7e82f3b`)
    .then(response => response.json())
    .then(data => {
      if (data.status === '1' && data.rectangle) {
        const rect = data.rectangle.split(';');
        const center = rect[0].split(',');
        const lng = parseFloat(center[0]);
        const lat = parseFloat(center[1]);
        
        // IP定位返回的已经是GCJ02坐标，无需转换
        currentLocation.value.longitude = lng;
        currentLocation.value.latitude = lat;
        
        if (h5map) {
          h5map.setCenter([lng, lat]);
          h5map.setZoom(13); // IP定位精度较低，缩小视图
          
          // 添加标记
          addMarkerToMap(lng, lat, 'IP定位位置');
        }
        
        uni.showToast({
          title: '使用IP定位',
          icon: 'none',
          duration: 2000
        });
      } else {
        throw new Error('IP定位失败');
      }
    })
    .catch((error) => {
      console.error('IP定位失败:', error);
      uni.showToast({
        title: '所有定位方式都失败',
        icon: 'none'
      });
    });
};

// 添加标记到地图
const addMarkerToMap = (lng, lat, title) => {
  // 清除现有标记
  h5map.clearMap();
  
  // 添加新标记
  const marker = new AMap.Marker({
    position: [lng, lat],
    title: title,
    map: h5map
  });
};

// 使用地理编码获取更精确的位置信息
const getPreciseAddress = (lng, lat) => {
  const geocoder = new AMap.Geocoder({
    city: "全国", // 城市，默认："全国"
    radius: 1000 // 范围，默认：500
  });
  
  geocoder.getAddress([lng, lat], (status, result) => {
    if (status === 'complete' && result.info === 'OK') {
      const address = result.regeocode.formattedAddress;
      console.log('精确地址:', address);
    }
  });
};

// 跳转到景点编辑页
const navigateToNotePage = () => {
  console.log('跳转时传递的坐标:', currentLocation.value);
  
  uni.navigateTo({
    url: `/pages/edit/edit?latitude=${currentLocation.value.latitude}&longitude=${currentLocation.value.longitude}`
  });
};
</script>

<style lang="scss" scoped>
.HomeLayout{
  .banner{
    width:750rpx;
    padding:30rpx 0;
    swiper{
      width:750rpx;
      height:340rpx;
      &-item{
        width:100%;
        height:100%;
        padding:0 30rpx;
        image{
          width:100%;
          height:100%;
          border-radius: 10rpx;
        }
      }
    }
  }
  
  .notice{
    width:690rpx;
    height:80rpx;
    line-height:80rpx;
    background:#f9f9f9 ;
    margin: 0 auto;
    border-radius: 80rpx;
    display:flex;
    .left{
      width:150rpx;
      display:flex;
      align-items: center;
      justify-content: center;
      .text{
        color: #ffa500;
        font-weight:600;
        font-size: 28rpx;
        margin-left: 8rpx;
      }
    }
    .center{
      flex:1;
      swiper{
        height: 100%;
        &-item{
          height: 100%;
          font-size: 30rpx;
          color:#666;
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
        }
      }
    }
    .right{
      width:70rpx;
      display:flex;
      align-items: center;
      justify-content: center;
    }
  }
  
  .map-container{
    width: 690rpx;
    height: 800rpx;
    margin: 100rpx auto 0;
    border-radius: 20rpx;
    overflow: hidden;
    position: relative;
    box-shadow: 0 4rpx 16rpx rgba(0,0,0,0.08);
    
    // 地图容器
    .we-map {
      width: 100%;
      height: 100%;
      position: relative;
    }
    
    // 发布笔记按钮
    .location-btn{
      position: absolute;
      top: 20rpx;
      right: 20rpx;
      width: 60rpx;
      height: 60rpx;
      background-color: #1890ff;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 4rpx 12rpx rgba(24,144,255,0.3);
      z-index: 999;
      touch-action: manipulation;
      transition: all 0.3s ease;
      
      &:active{
        transform: scale(0.92);
        background-color: #096dd9;
      }
    }
  }
}

.pageBg{
  background-color: #ffffff;
  min-height: 100vh;
}
</style>