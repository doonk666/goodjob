<template>
	<view class="set-page pageBg">
		<view class="section">
			<view class="list">
				<!-- 账号与安全 -->
				<view class="row" @click="goToAccountSecurity">
					<view class="left">
						<uni-icons type="locked-filled" size="20" color="#1890ff"></uni-icons>
						<view class="text">账号与安全</view>
					</view>
					<view class="right">
						<uni-icons type="right" size="20" color="#ccc"></uni-icons>
					</view>
				</view>
				
				<!-- 隐私设置 -->
				<view class="row" @click="goToPrivacy">
					<view class="left">
						<uni-icons type="eye-filled" size="20" color="#52c41a"></uni-icons>
						<view class="text">隐私设置</view>
					</view>
					<view class="right">
						<uni-icons type="right" size="20" color="#ccc"></uni-icons>
					</view>
				</view>
				
				<!-- 通知设置 -->
				<view class="row" @click="goToNotification">
					<view class="left">
						<uni-icons type="sound-filled" size="20" color="#fa8c16"></uni-icons>
						<view class="text">通知设置</view>
					</view>
					<view class="right">
						<uni-icons type="right" size="20" color="#ccc"></uni-icons>
					</view>
				</view>
			</view>
		</view>

		<view class="section">
			<view class="list">
				<!-- 清除缓存 -->
				<view class="row" @click="clearCache">
					<view class="left">
						<uni-icons type="trash-filled" size="20" color="#fa541c"></uni-icons>
						<view class="text">清除缓存</view>
					</view>
					<view class="right">
						<view class="cache-size">{{ cacheSize }}</view>
						<uni-icons type="right" size="20" color="#ccc"></uni-icons>
					</view>
				</view>
				
				<!-- 关于我们 -->
				<view class="row" @click="goToAbout">
					<view class="left">
						<uni-icons type="info-filled" size="20" color="#722ed1"></uni-icons>
						<view class="text">关于我们</view>
					</view>
					<view class="right">
						<uni-icons type="right" size="20" color="#ccc"></uni-icons>
					</view>
				</view>
			</view>
		</view>

		<view class="section">
			<view class="list">
				<!-- 用户协议 -->
				<view class="row" @click="goToUserAgreement">
					<view class="left">
						<uni-icons type="paperclip" size="20" color="#13c2c2"></uni-icons>
						<view class="text">用户协议</view>
					</view>
					<view class="right">
						<uni-icons type="right" size="20" color="#ccc"></uni-icons>
					</view>
				</view>
				
				<!-- 隐私政策 -->
				<view class="row" @click="goToPrivacyPolicy">
					<view class="left">
						<uni-icons type="security-scan" size="20" color="#eb2f96"></uni-icons>
						<view class="text">隐私政策</view>
					</view>
					<view class="right">
						<uni-icons type="right" size="20" color="#ccc"></uni-icons>
					</view>
				</view>
			</view>
		</view>

		<!-- 版本信息 -->
		<view class="version">
			版本号 {{ version }}
		</view>
	</view>
</template>

<script setup>
	import { ref, onMounted } from 'vue';

	// 版本信息
	const version = ref('1.0.0');
	
	// 缓存大小
	const cacheSize = ref('0 MB');

	onMounted(() => {
		// 计算缓存大小
		calculateCacheSize();
		
		// TODO: 接口1 - 获取应用版本信息
		// fetchAppVersion();
	});

	// TODO: 接口1 - 获取应用版本信息
	// 建议接口：GET /api/app/version
	// 返回：{ version: '1.0.0', downloadUrl: '', forceUpdate: false }
	// const fetchAppVersion = async () => {
	//   try {
	//     const res = await uni.request({
	//       url: '/api/app/version',
	//       method: 'GET'
	//     });
	//     
	//     if (res.data.code === 200) {
	//       version.value = res.data.data.version;
	//     }
	//   } catch (error) {
	//     console.error('获取版本信息失败:', error);
	//   }
	// };

	// 计算缓存大小
	const calculateCacheSize = () => {
		try {
			// 这里可以计算实际缓存大小
			// 目前先用模拟数据
			const size = Math.random() * 10 + 5; // 5-15MB
			cacheSize.value = `${size.toFixed(1)} MB`;
			
			// TODO: 接口2 - 获取准确的缓存大小（如果需要服务端数据）
			// fetchCacheSize();
		} catch (error) {
			cacheSize.value = '0 MB';
		}
	};

	// TODO: 接口2 - 获取缓存大小（如果需要服务端数据）
	// 建议接口：GET /api/user/cache-size
	// 返回：{ cacheSize: 1024 } // 单位KB
	// const fetchCacheSize = async () => {
	//   try {
	//     const token = uni.getStorageSync('token');
	//     const res = await uni.request({
	//       url: '/api/user/cache-size',
	//       method: 'GET',
	//       header: {
	//         'Authorization': `Bearer ${token}`
	//       }
	//     });
	//     
	//     if (res.data.code === 200) {
	//       const sizeInMB = (res.data.data.cacheSize / 1024).toFixed(1);
	//       cacheSize.value = `${sizeInMB} MB`;
	//     }
	//   } catch (error) {
	//     console.error('获取缓存大小失败:', error);
	//   }
	// };

	// 清除缓存
	const clearCache = () => {
		uni.showModal({
			title: '清除缓存',
			content: `确定要清除 ${cacheSize.value} 缓存吗？`,
			success: (res) => {
				if (res.confirm) {
					uni.showLoading({ title: '清除中...' });
					
					// 模拟清除缓存过程
					setTimeout(() => {
						// 清除各种缓存数据
						const keys = ['tempData', 'cacheData'];
						keys.forEach(key => {
							try {
								uni.removeStorageSync(key);
							} catch (e) {
								console.log(`清除 ${key} 失败:`, e);
							}
						});
						
						uni.hideLoading();
						cacheSize.value = '0 MB';
						uni.showToast({ title: '缓存清除成功' });
						
						// TODO: 接口3 - 通知服务端清除缓存（如果需要）
						// clearServerCache();
					}, 1000);
				}
			}
		});
	};

	// TODO: 接口3 - 清除服务端缓存
	// 建议接口：POST /api/user/clear-cache
	// 返回：{ success: true, message: '缓存清除成功' }
	// const clearServerCache = async () => {
	//   try {
	//     const token = uni.getStorageSync('token');
	//     const res = await uni.request({
	//       url: '/api/user/clear-cache',
	//       method: 'POST',
	//       header: {
	//         'Authorization': `Bearer ${token}`
	//       }
	//     });
	//     
	//     if (res.data.code !== 200) {
	//       console.error('清除服务端缓存失败');
	//     }
	//   } catch (error) {
	//     console.error('清除服务端缓存失败:', error);
	//   }
	// };

	// 跳转到账号与安全
	const goToAccountSecurity = () => {
		// TODO: 接口4 - 获取账号安全状态（在账号安全页面使用）
		// 建议接口：GET /api/user/security-status
		// 返回：{ hasPassword: true, bindPhone: true, bindEmail: false, lastLogin: '2023-01-01' }
		
		uni.showToast({ 
			title: '账号与安全页面开发中', 
			icon: 'none' 
		});
		// uni.navigateTo({ url: '/pages/account-security/account-security' });
	};

	// 跳转到隐私设置
	const goToPrivacy = () => {
		// TODO: 接口5 - 获取隐私设置（在隐私设置页面使用）
		// 建议接口：GET /api/user/privacy-settings
		// 返回：{ profileVisible: 'public', locationVisible: 'friends', dataSync: true }
		
		uni.showToast({ 
			title: '隐私设置页面开发中', 
			icon: 'none' 
		});
		// uni.navigateTo({ url: '/pages/privacy/privacy' });
	};

	// 跳转到通知设置
	const goToNotification = () => {
		// TODO: 接口6 - 获取通知设置（在通知设置页面使用）
		// 建议接口：GET /api/user/notification-settings
		// 返回：{ pushEnabled: true, soundEnabled: true, vibrationEnabled: false }
		
		uni.showToast({ 
			title: '通知设置页面开发中', 
			icon: 'none' 
		});
		// uni.navigateTo({ url: '/pages/notification/notification' });
	};

	// 跳转到关于我们
	const goToAbout = () => {
		// TODO: 接口7 - 获取关于我们内容（在关于我们页面使用）
		// 建议接口：GET /api/app/about
		// 返回：{ content: '应用介绍...', contact: 'contact@example.com', website: 'https://example.com' }
		
		uni.showToast({ 
			title: '关于我们页面开发中', 
			icon: 'none' 
		});
		// uni.navigateTo({ url: '/pages/about/about' });
	};

	// 跳转到用户协议
	const goToUserAgreement = () => {
		// TODO: 接口8 - 获取用户协议内容（在用户协议页面使用）
		// 建议接口：GET /api/app/user-agreement
		// 返回：{ title: '用户协议', content: '协议内容...', updateTime: '2023-01-01' }
		
		uni.showToast({ 
			title: '用户协议页面开发中', 
			icon: 'none' 
		});
		// uni.navigateTo({ url: '/pages/user-agreement/user-agreement' });
	};

	// 跳转到隐私政策
	const goToPrivacyPolicy = () => {
		// TODO: 接口9 - 获取隐私政策内容（在隐私政策页面使用）
		// 建议接口：GET /api/app/privacy-policy
		// 返回：{ title: '隐私政策', content: '政策内容...', updateTime: '2023-01-01' }
		
		uni.showToast({ 
			title: '隐私政策页面开发中', 
			icon: 'none' 
		});
		// uni.navigateTo({ url: '/pages/privacy-policy/privacy-policy' });
	};
</script>

<style lang="scss" scoped>
.set-page {
	min-height: 100vh;
	padding: 20rpx 0;
	
	.section {
		width: 690rpx;
		margin: 30rpx auto;
		border: 1px solid #eee;
		border-radius: 10rpx;
		box-shadow: 0 0 30rpx rgba(0, 0, 0, 0.05);
		background: #fff;
		
		.list {
			.row {
				display: flex;
				justify-content: space-between;
				align-items: center;
				padding: 0 30rpx;
				height: 100rpx;
				border-bottom: 1px solid #eee;
				
				&:last-child {
					border-bottom: 0;
				}
				
				.left {
					display: flex;
					align-items: center;
					gap: 20rpx;
					
					.text {
						font-size: 32rpx;
						color: #333;
					}
				}
				
				.right {
					display: flex;
					align-items: center;
					gap: 15rpx;
					
					.cache-size {
						font-size: 28rpx;
						color: #999;
					}
				}
			}
		}
	}
	
	.version {
		text-align: center;
		font-size: 28rpx;
		color: #999;
		margin-top: 50rpx;
		padding: 20rpx;
	}
}
</style>