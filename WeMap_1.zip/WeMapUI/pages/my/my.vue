<template>
	<view class="MyLayout pageBg">
		<view class="userInfo">
			<!-- 头像区域：支持编辑 -->
			<view class="avatar" @click="handleAvatarClick">
				<image :src="userInfo.avatar" mode="aspectFill"></image>
				<view class="avatar-edit">
					<uni-icons type="camera-filled" size="24" color="#fff"></uni-icons>
				</view>
			</view>
			<!-- 昵称区域：支持编辑 -->
			<view class="nickname-container">
				<view class="nickname">{{ userInfo.nickname }}</view>
				<uni-icons 
					type="compose" 
					size="24" 
					color="#666" 
					class="edit-icon"
					@click.stop="editNickname"
				></uni-icons>
			</view>
			<!-- 适配：显示账号（原手机号替换为账号，更贴合登录逻辑） -->
			<view class="account">账号：{{ userInfo.username || '未绑定账号' }}</view>
		</view>
		<!-- 以下列表部分添加跳转事件 -->
		<view class="section">
			<view class="list">
				<!-- 我的收藏：动态显示数量 -->
				<view class="row" @click="goToMyCollection">
					<view class="left">
						<uni-icons type="star-filled" size="20" color="#ffa500"></uni-icons>
						<view class="text">我的收藏</view>
					</view>
					<view class="right">
						<view class="text">{{ collectionCount }}</view>
						<uni-icons type="right" size="20"></uni-icons>
					</view>
				</view>
				<!-- 我的点赞：动态显示数量 -->
				<view class="row" @click="goToMyLike">
					<view class="left">
						<uni-icons type="heart-filled" size="20" color="#ffa500"></uni-icons>
						<view class="text">我的点赞</view>
					</view>
					<view class="right">
						<view class="text">{{ likeCount }}</view>
						<uni-icons type="right" size="20"></uni-icons>
					</view>
				</view>
				<!-- 我的标注：动态显示数量 -->
				<view class="row" @click="goToMyMark">
					<view class="left">
						<uni-icons type="flag-filled" size="20" color="#ffa500"></uni-icons>
						<view class="text">我的标注</view>
					</view>
					<view class="right">
						<view class="text">{{ markCount }}</view>
						<uni-icons type="right" size="20"></uni-icons>
					</view>
				</view>
			</view>
		</view>
		<view class="section">
			<view class="list">
				<view class="row" @click="goToKefu">
					<view class="left">
						<uni-icons type="person-filled" size="20" color="#808080"></uni-icons>
						<view class="text">联系客服</view>
					</view>
					<view class="right">
						<uni-icons type="right" size="20"></uni-icons>
					</view>
				</view>
				<view class="row" @click="goToSet">
					<view class="left">
						<uni-icons type="gear-filled" size="20" color="#808080"></uni-icons>
						<view class="text">设置</view>
					</view>
					<view class="right">
						<uni-icons type="right" size="20"></uni-icons>
					</view>
				</view>
				<view class="row" @click="logout">
					<view class="left">
						<uni-icons type="logout" size="20" color="#ff4d4f"></uni-icons>
						<view class="text" style="color: #ff4d4f;">退出登录</view>
					</view>
					<view class="right">
						<uni-icons type="right" size="20" color="#ff4d4f"></uni-icons>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script setup>
	import { ref, onMounted, watch } from 'vue';

	// 初始化用户信息（适配账号密码登录：新增username字段，移除address）
	const userInfo = ref({
	  avatar: '/common/images/头像.jpg',
	  nickname: '未登录',
	  username: '' // 账号字段（与登录页同步）
	});

	// 新增：定义三个数量变量，用于动态显示
	const collectionCount = ref(0); // 收藏数量
	const likeCount = ref(0);       // 点赞数量
	const markCount = ref(0);       // 标注数量

	// 页面加载时读取缓存的用户信息和笔记数量
	onMounted(() => {
	  const cacheUser = uni.getStorageSync('userInfo');
	  if (cacheUser) {
	    // 适配：如果缓存中有旧结构（phone字段），优先显示phone；否则显示username
	    userInfo.value = {
	      ...cacheUser,
	      username: cacheUser.username || cacheUser.phone || '' // 兼容旧数据
	    };
	  }
	  
	  // 加载缓存中的笔记数据，更新数量
	  loadNoteCounts();
	  
	  // TODO: 接口1 - 获取用户基本信息
	  // fetchUserProfile();
	});

	// 监听用户登录状态变化，更新笔记数量
	watch(() => userInfo.value.username, (newVal) => {
	  if (newVal) {
	    loadNoteCounts(); // 登录后加载数量
	    // TODO: 登录后重新获取所有数据
	    // fetchUserProfile();
	    // fetchUserStats();
	  } else {
	    // 未登录时重置数量为0
	    collectionCount.value = 0;
	    likeCount.value = 0;
	    markCount.value = 0;
	  }
	});

	// 加载笔记数量（从缓存中读取）
	const loadNoteCounts = () => {
	  // 从缓存获取各类型笔记数据
	  const collectionNotes = uni.getStorageSync('collectionNotes') || [];
	  const likeNotes = uni.getStorageSync('likeNotes') || [];
	  const markNotes = uni.getStorageSync('markNotes') || [];
	  
	  // 更新数量
	  collectionCount.value = collectionNotes.length;
	  likeCount.value = likeNotes.length;
	  markCount.value = markNotes.length;
	};

	// TODO: 接口1实现 - 获取用户基本信息
	// const fetchUserProfile = async () => {
	//   try {
	//     // 从缓存获取用户token或ID
	//     const token = uni.getStorageSync('token');
	//     if (!token) return;
	    
	//     // 调用获取用户信息的接口
	//     const res = await uni.request({
	//       url: '/api/user/profile',
	//       method: 'GET',
	//       header: {
	//         'Authorization': `Bearer ${token}`
	//       }
	//     });
	    
	//     if (res.data.code === 200) {
	//       userInfo.value = res.data.data;
	//       // 更新缓存
	//       uni.setStorageSync('userInfo', res.data.data);
	//     }
	//   } catch (error) {
	//     console.error('获取用户信息失败:', error);
	//     // 失败时使用缓存数据
	//     const cacheUser = uni.getStorageSync('userInfo');
	//     if (cacheUser) {
	//       userInfo.value = cacheUser;
	//     }
	//   }
	// };

	// TODO: 接口2 - 获取用户统计数据
	// const fetchUserStats = async () => {
	//   try {
	//     const token = uni.getStorageSync('token');
	//     if (!token) return;
	    
	//     const res = await uni.request({
	//       url: '/api/user/stats',
	//       method: 'GET',
	//       header: {
	//         'Authorization': `Bearer ${token}`
	//       }
	//     });
	    
	//     if (res.data.code === 200) {
	//       const stats = res.data.data;
	//       collectionCount.value = stats.collectionCount || 0;
	//       likeCount.value = stats.likeCount || 0;
	//       markCount.value = stats.markCount || 0;
	//     }
	//   } catch (error) {
	//     console.error('获取用户统计数据失败:', error);
	//     // 失败时使用缓存数据
	//     loadNoteCounts();
	//   }
	// };

	// 原有方法保持不变
	const goBack = () => {
	  uni.navigateBack();
	};
	
	const goToKefu = () => {
	  uni.navigateTo({ url: '/pages/kefu/kefu' });
	};
	
	// 新增：跳转到设置页面
	const goToSet = () => {
	  uni.navigateTo({ url: '/pages/set/set' });
	};
	
	const logout = () => {
	  uni.showModal({
	    title: '提示',
	    content: '确定要退出登录吗？',
	    cancelText: '取消',
	    confirmText: '确定',
	    success: (res) => {
	      if (res.confirm) {
	        uni.removeStorageSync('userInfo');
	        // 退出登录后重置数量
	        collectionCount.value = 0;
	        likeCount.value = 0;
	        markCount.value = 0;
	        uni.redirectTo({ url: '/pages/login/login' });
	      }
	    }
	  });
	};
	
	const handleAvatarClick = () => {
	  if (!userInfo.value.username) {
	    uni.showToast({ title: '请先登录', icon: 'none' });
	    return;
	  }
	  uni.showActionSheet({
	    itemList: ['预览头像', '从相册选择', '拍照上传'],
	    itemColor: '#333',
	    success: (res) => {
	      switch (res.tapIndex) {
	        case 0:
	          previewAvatar();
	          break;
	        case 1:
	          chooseAvatar('album');
	          break;
	        case 2:
	          chooseAvatar('camera');
	          break;
	      }
	    }
	  });
	};
	
	const previewAvatar = () => {
	  uni.previewImage({
	    urls: [userInfo.value.avatar],
	    current: userInfo.value.avatar,
	    loop: true
	  });
	};
	
	// TODO: 接口3 - 更新用户头像
	const chooseAvatar = (type) => {
	  uni.chooseImage({
	    count: 1,
	    sourceType: [type],
	    sizeType: ['compressed'],
	    success: (res) => {
	      const tempAvatarPath = res.tempFilePaths[0];
	      uni.showLoading({ title: '上传中...' });
	      setTimeout(() => {
	        userInfo.value.avatar = tempAvatarPath;
	        uni.setStorageSync('userInfo', userInfo.value);
	        uni.hideLoading();
	        uni.showToast({ title: '头像更新成功' });
	      }, 800);
	      
	      // TODO: 接口调用方式
	      // try {
	      //   const uploadRes = await uni.uploadFile({
	      //     url: '/api/user/avatar',
	      //     filePath: tempAvatarPath,
	      //     name: 'avatar',
	      //     header: {
	      //       'Authorization': `Bearer ${uni.getStorageSync('token')}`
	      //     }
	      //   });
	        
	      //   const data = JSON.parse(uploadRes.data);
	      //   if (data.code === 200) {
	      //     userInfo.value.avatar = data.data.avatarUrl;
	      //     uni.setStorageSync('userInfo', userInfo.value);
	      //     uni.showToast({ title: '头像更新成功' });
	      //   } else {
	      //     uni.showToast({ title: '上传失败', icon: 'none' });
	      //   }
	      // } catch (error) {
	      //   console.error('上传头像失败:', error);
	      //   uni.showToast({ title: '上传失败', icon: 'none' });
	      // } finally {
	      //   uni.hideLoading();
	      // }
	    },
	    fail: () => {
	      uni.showToast({ title: '选择图片失败', icon: 'none' });
	    }
	  });
	};
	
	// TODO: 接口4 - 更新用户昵称
	const editNickname = () => {
	  uni.showModal({
	    title: '修改昵称',
	    editable: true,
	    placeholderText: '请输入新昵称（1-12字）',
	    value: userInfo.value.nickname,
	    success: (res) => {
	      if (res.confirm) {
	        const nickname = res.content.trim();
	        if (!nickname) {
	          uni.showToast({ title: '昵称不能为空', icon: 'none' });
	          return;
	        }
	        if (nickname.length > 12) {
	          uni.showToast({ title: '昵称长度不能超过12字', icon: 'none' });
	          return;
	        }
	        userInfo.value.nickname = nickname;
	        uni.setStorageSync('userInfo', userInfo.value);
	        uni.showToast({ title: '昵称修改成功' });
	        
	        // TODO: 接口调用方式
	        // try {
	        //   const updateRes = await uni.request({
	        //     url: '/api/user/nickname',
	        //     method: 'PUT',
	        //     data: { nickname },
	        //     header: {
	        //       'Authorization': `Bearer ${uni.getStorageSync('token')}`
	        //     }
	        //   });
	          
	        //   if (updateRes.data.code === 200) {
	        //     userInfo.value.nickname = nickname;
	        //     uni.setStorageSync('userInfo', userInfo.value);
	        //     uni.showToast({ title: '昵称修改成功' });
	        //   } else {
	        //     uni.showToast({ title: '更新失败', icon: 'none' });
	        //   }
	        // } catch (error) {
	        //   console.error('更新昵称失败:', error);
	        //   uni.showToast({ title: '更新失败', icon: 'none' });
	        // }
	      }
	    }
	  });
	};

	// 新增：跳转至我的收藏页面
	const goToMyCollection = () => {
	  if (!userInfo.value.username) {
	    uni.showToast({ title: '请先登录', icon: 'none' });
	    return;
	  }
	  uni.navigateTo({ url: '/pages/my-collection/my-collection' });
	};

	// 新增：跳转至我的点赞页面
	const goToMyLike = () => {
	  if (!userInfo.value.username) {
	    uni.showToast({ title: '请先登录', icon: 'none' });
	    return;
	  }
	  uni.navigateTo({ url: '/pages/my-like/my-like' });
	};

	// 新增：跳转至我的标注页面
	const goToMyMark = () => {
	  if (!userInfo.value.username) {
	    uni.showToast({ title: '请先登录', icon: 'none' });
	    return;
	  }
	  uni.navigateTo({ url: '/pages/my-mark/my-mark' });
	};

	// 提供给子页面调用的更新数量方法（通过uni.$on监听）
	uni.$on('updateNoteCounts', () => {
	  loadNoteCounts();
	});
</script>

<style lang="scss">
.MyLayout{
	.userInfo{
		display: flex;
		align-items: center;
		justify-content: center;
		flex-direction: column;
		padding: 50rpx 0;
		.avatar{
			width: 160rpx;
			height: 160rpx;
			border-radius: 50%;
			overflow: hidden;
			position: relative;
			border: 2rpx solid #eee;
			image{
				width: 100%;
				height: 100%;
			}
			.avatar-edit{
				position: absolute;
				bottom: 0;
				right: 0;
				width: 40rpx;
				height: 40rpx;
				background: rgba(0,0,0,0.5);
				border-radius: 50%;
				display: flex;
				align-items: center;
				justify-content: center;
			}
		}
		.nickname-container{
			display: flex;
			align-items: center;
			gap: 10rpx;
			margin: 20rpx 0 10rpx;
		}
		.nickname{
			font-size: 44rpx;
			color: #333;
		}
		.edit-icon{
			cursor: pointer;
			margin-top: 5rpx;
			display: flex;
			align-items: center;
			justify-content: center;
		}
		// 新增：账号显示样式（替换原phone样式）
		.account{
			font-size: 28rpx;
			color: #666;
		}
	}
	// 以下样式完全不变
	.section{
		width: 690rpx;
		margin: 50rpx auto;
		border: 1px solid #eee;
		border-radius: 10rpx;
		box-shadow: 0 0 30rpx rgba(0, 0, 0, 0.05);
		.list{
			.row{
				display: flex;
				justify-content: space-between;
				align-items: center;
				padding: 0 30rpx;
				height: 100rpx;
				border-bottom: 1px solid #eee;
				background: #fff;
				&:last-child{border-bottom:0}
				.left{
					display: flex;
					align-items: center;
					gap: 20rpx;
				}
				.right{
					display: flex;
					align-items: center;
					gap: 15rpx;
				}
				.text{
					font-size: 32rpx;
				}
			}
		}
	}
}   
</style>