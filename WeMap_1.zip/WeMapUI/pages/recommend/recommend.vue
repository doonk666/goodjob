<template>
  <view class="recommend-page pageBg">
    <!-- 顶部搜索栏 -->
    <view class="search-container" :class="{ 'search-focused': isSearchFocused }">
      <view class="search-bar">
        <uni-icons type="search" size="18" color="#888" class="search-icon" />
        <input
          type="text"
          v-model="searchInput"
          placeholder="搜索小众景点、地点或作者..."
          class="search-input"
          @focus="handleInputFocus"
          @blur="handleInputBlur"
          @confirm="handleSearch" 
          confirm-type="search"
        />
        <text 
          class="search-button" 
          :class="{ 'search-button-active': searchInput }"
          @click="handleSearch"
        >
          搜索
        </text>
        <uni-icons
          type="close"
          size="16"
          color="#888"
          class="clear-icon"
          v-if="searchInput"
          @click="clearSearch"
        />
      </view>

      <view class="search-panel" v-if="isSearchFocused">
        <view class="hot-search">
          <view class="panel-header">
            <text class="panel-title">热门搜索</text>
          </view>
          <view class="tag-list">
            <view
              class="hot-tag"
              v-for="(item, index) in hotSearchList"
              :key="index"
              @click="searchByTag(item)"
            >
              <span class="tag-rank" :class="getRankClass(index)">{{ index + 1 }}</span>
              {{ item }}
            </view>
          </view>
        </view>
      </view>
    </view>

    <!-- 推荐内容区 -->
    <scroll-view
      class="content-scroll"
      scroll-y
      @scrolltolower="handleScrollToLower"
      @touchstart="handleTouchStart"
      @touchend="handleTouchEnd"
      @touchmove="handleTouchMove"
    >
      <!-- 自定义下拉刷新区域 -->
      <view 
        class="custom-refresher" 
        :style="{ height: refresherHeight + 'px' }"
      >
        <text v-if="isRefreshing" class="refresher-text">刷新中...</text>
      </view>

      <!-- 顶部留白 -->
      <view class="top-padding"></view>

      <!-- 搜索结果提示 -->
      <view class="search-result-tip" v-if="isSearchActive && filteredNoteList.length > 0">
        <uni-icons type="search" size="14" color="#666" class="tip-icon" />
        找到 {{ filteredNoteList.length }} 个相关结果
        <text class="search-keyword">"{{ searchKeyword }}"</text>
      </view>

      <!-- 无结果空状态 -->
      <view class="empty-state" v-if="isSearchActive && filteredNoteList.length === 0">
        <uni-icons type="search" size="64" color="#eee" class="empty-icon" />
        <text class="empty-text">没有找到相关景点呢～</text>
        <text class="empty-tip">试试换个关键词或搜索热门景点</text>
        <view class="empty-hot-tags" v-if="hotSearchList.length > 0">
          <text class="tag-label">热门推荐：</text>
          <view class="tag-scroll">
            <view
              class="empty-tag"
              v-for="(item, index) in hotSearchList.slice(0, 5)"
              :key="index"
              @click="searchByTag(item)"
            >
              {{ item }}
            </view>
          </view>
        </view>
      </view>

      <!-- 推荐列表 -->
      <view class="note-grid">
        <view
          class="note-card"
          v-for="(item, index) in currentNoteList"
          :key="item.id"
          @click="navigateToDetail(item)"
        >
          <view class="card-cover">
            <image :src="item.cover" mode="aspectFill" class="cover-img" lazy-load />
            <view class="img-count" v-if="item.images && item.images.length > 1">
              <uni-icons type="images" size="12" color="#fff" />
              <text class="count-text">{{ item.images.length }}</text>
            </view>
            <view class="publish-time">
              {{ item.publishTime }}
            </view>
          </view>

          <view class="card-content">
            <text class="card-title font-medium">{{ item.title }}</text>
            <view class="card-meta">
              <text class="card-author">{{ item.author }}</text>
              <text class="meta-separator">·</text>
              <text class="card-location">{{ item.location }}</text>
            </view>
            <view class="card-stats">
              <view class="stat-item">
                <uni-icons type="heart" size="13" color="#ff2442" />
                <text class="stat-text">{{ formatNum(item.likes) }}</text>
              </view>
              <view class="stat-item">
                <uni-icons type="chatbubble" size="13" color="#888" />
                <text class="stat-text">{{ formatNum(item.comments) }}</text>
              </view>
              <view class="stat-item">
                <uni-icons type="share" size="13" color="#888" />
                <text class="stat-text">{{ formatNum(item.shares) }}</text>
              </view>
            </view>
          </view>
        </view>
      </view>

      <!-- 加载状态 -->
      <view class="loading-footer" v-if="!isSearchActive">
        <view v-if="isLoading" class="loading-content">
          <uni-icons type="spinner" size="16" color="#888" class="loading-icon" animation="spin" />
          <text class="loading-text">加载中...</text>
        </view>
        <text v-else-if="hasMore" class="load-more-text">上拉加载更多</text>
        <text v-else class="no-more-text">没有更多内容啦～</text>
      </view>

      <!-- 底部留白 -->
      <view class="bottom-padding"></view>
    </scroll-view>
  </view>
</template>

<script setup>
import { ref, computed, onMounted, getCurrentInstance } from 'vue';

// 搜索相关状态
const searchInput = ref(''); // 输入框内容
const searchKeyword = ref(''); // 实际搜索关键词
const isSearchActive = ref(false); // 是否正在进行搜索
const isSearchFocused = ref(false);
const hotSearchList = ref([
  "浙江小众景点", "海边露营", "无人村落", "草原湖泊",
  "复古文创园", "徒步路线", "隐秘瀑布", "梯田云海",
  "沙漠露营", "海岛度假", "雪山徒步", "古镇漫游"
]);

// 列表相关状态
const noteList = ref([]);
const filteredNoteList = ref([]);
const currentNoteList = computed(() => isSearchActive.value ? filteredNoteList.value : noteList.value);
const page = ref(1);
const pageSize = ref(8);
const hasMore = ref(true);
const isLoading = ref(false);

// 自定义下拉刷新状态
const startY = ref(0);
const refresherHeight = ref(0);
const isRefreshing = ref(false);
const maxRefresherHeight = ref(60);
const refreshThreshold = ref(30);

// 初始化加载数据
onMounted(() => {
  fetchNoteList();
});

// 触摸开始：记录起始位置
const handleTouchStart = (e) => {
  if (!isRefreshing.value) {
    startY.value = e.changedTouches[0].clientY;
  }
};

// 触摸移动：计算下拉高度
const handleTouchMove = (e) => {
  if (isRefreshing.value) return;

  const query = uni.createSelectorQuery().in(getCurrentInstance());
  query.select('.content-scroll').fields({ scrollOffset: true }, (res) => {
    if (res?.scrollTop <= 0) {
      const moveY = e.changedTouches[0].clientY;
      const diff = moveY - startY.value;
      
      if (diff > 0) {
        refresherHeight.value = Math.min(diff / 2, maxRefresherHeight.value);
      }
    }
  }).exec();
};

// 触摸结束：判断是否触发刷新
const handleTouchEnd = () => {
  if (isRefreshing.value) return;

  if (refresherHeight.value >= refreshThreshold.value) {
    startRefresh();
  } else {
    refresherHeight.value = 0;
  }
};

// 开始刷新
const startRefresh = () => {
  isRefreshing.value = true;
  refresherHeight.value = maxRefresherHeight.value;

  page.value = 1;
  hasMore.value = true;
  noteList.value = [];

  fetchNoteList().then(() => {
    setTimeout(() => {
      isRefreshing.value = false;
      refresherHeight.value = 0;
    }, 500);
  });
};

// TODO: 需要引入获取热门搜索接口
const fetchHotSearchList = async () => {
  try {
    // 接口地址：/api/search/hot
    // const response = await uni.request({
    //   url: '/api/search/hot',
    //   method: 'GET'
    // });
    // hotSearchList.value = response.data.list;
    
    console.log('获取热门搜索列表');
  } catch (error) {
    console.error('获取热门搜索失败:', error);
  }
};

// TODO: 需要引入获取推荐笔记列表接口
const fetchNoteList = async () => {
  if ((!isRefreshing.value && isLoading.value) || !hasMore.value) return;

  if (!isRefreshing.value) {
    isLoading.value = true;
  }

  try {
    // TODO: 替换为真实接口调用
    // 接口地址：/api/notes/recommend
    // const response = await uni.request({
    //   url: '/api/notes/recommend',
    //   method: 'GET',
    //   data: {
    //     page: page.value,
    //     pageSize: pageSize.value
    //   }
    // });
    
    // 模拟接口请求延迟
    await new Promise(resolve => setTimeout(resolve, 1000));

    // 模拟生成数据
    const newData = Array.from({ length: pageSize.value }, (_, i) => {
      const id = (page.value - 1) * pageSize.value + i + 1;
      const imgCount = Math.floor(Math.random() * 4) + 1;
      const images = Array.from({ length: imgCount }, (_, j) => `https://picsum.photos/seed/spot${id + j * 100}/600/400`);
      
      return {
        id: `note_${id}`,
        title: getRandomTitle(),
        cover: images[0],
        images,
        author: getRandomAuthor(),
        location: getRandomLocation(),
        likes: Math.floor(Math.random() * 9999) + 100,
        comments: Math.floor(Math.random() * 999) + 10,
        shares: Math.floor(Math.random() * 500) + 5,
        publishTime: `${Math.floor(Math.random() * 30) + 1}天前`
      };
    });

    noteList.value.push(...newData);
    if (page.value >= 5) hasMore.value = false;
    page.value++;
  } catch (error) {
    console.error('加载笔记失败:', error);
    uni.showToast({ title: '加载失败，请重试', icon: 'none' });
  } finally {
    if (!isRefreshing.value) {
      isLoading.value = false;
    }
  }
};

// 上拉加载更多
const handleScrollToLower = () => {
  if (!isSearchActive.value && !isRefreshing.value && !isLoading.value && hasMore.value) {
    fetchNoteList();
  }
};

// 搜索相关方法
const handleInputFocus = () => {
  isSearchFocused.value = true;
};

const handleInputBlur = () => {
  setTimeout(() => {
    isSearchFocused.value = false;
  }, 200);
};

// TODO: 需要引入搜索接口
const handleSearch = async () => {
  const keyword = searchInput.value.trim();
  if (keyword) {
    isSearchActive.value = true;
    searchKeyword.value = keyword;
    isSearchFocused.value = false;
    
    try {
      // TODO: 替换为后端搜索接口
      // 模拟搜索请求延迟
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 前端过滤逻辑
      filteredNoteList.value = noteList.value.filter(item => 
        item.title.toLowerCase().includes(keyword.toLowerCase()) ||
        item.location.toLowerCase().includes(keyword.toLowerCase()) ||
        item.author.toLowerCase().includes(keyword.toLowerCase())
      );
      
      // TODO: 后端搜索接口调用示例
      // const response = await uni.request({
      //   url: '/api/search/notes',
      //   method: 'GET',
      //   data: {
      //     keyword: keyword,
      //     page: 1,
      //     pageSize: 50
      //   }
      // });
      // filteredNoteList.value = response.data.list;
      
    } catch (error) {
      console.error('搜索失败:', error);
      uni.showToast({ title: '搜索失败，请重试', icon: 'none' });
    }
  } else {
    uni.showToast({ title: '请输入搜索关键词', icon: 'none' });
  }
};

const clearSearch = () => {
  searchInput.value = '';
  searchKeyword.value = '';
  isSearchActive.value = false;
  filteredNoteList.value = [];
};

const searchByTag = (tag) => {
  searchInput.value = tag;
  handleSearch();
};

// TODO: 需要引入笔记详情接口
const navigateToDetail = (item) => {
  uni.navigateTo({
    url: `/pages/detail/detail?${Object.entries({
      id: item.id,
      title: item.title,
      cover: item.cover,
      images: JSON.stringify(item.images),
      author: item.author,
      location: item.location,
      likes: item.likes,
      comments: item.comments,
      shares: item.shares,
      publishTime: item.publishTime
    }).map(([key, value]) => `${key}=${encodeURIComponent(value)}`).join('&')}`
  });
};

// 辅助方法
const getRankClass = (index) => {
  if (index === 0) return 'rank-1';
  if (index === 1) return 'rank-2';
  if (index === 2) return 'rank-3';
  return 'rank-other';
};

const formatNum = (num) => {
  if (num >= 10000) {
    return (num / 10000).toFixed(1) + '万';
  }
  return num;
};

const getRandomTitle = () => {
  const titles = [
    "藏在山谷里的无人村落，像走进了宫崎骏的动画",
    "海边废弃灯塔，阴天拍照自带电影感",
    "徒步2小时才到的草原湖泊，手机拍不出的蓝",
    "小众古村｜没有商业化，只有烟火气",
    "复古文创园里的宝藏角落，超出片",
    "隐秘瀑布｜本地人都很少知道的秘境",
    "梯田云海｜清晨五点的治愈时刻",
    "沙漠露营｜星空下的浪漫体验",
    "海岛小众沙滩，人少景美还免费",
    "雪山脚下的村庄，仿佛闯入童话世界",
    "千年古镇，避开人群的慢生活之旅",
    "秋日红叶秘境，拍照不用挤景区"
  ];
  return titles[Math.floor(Math.random() * titles.length)];
};

const getRandomAuthor = () => {
  const authors = ["漫游君", "岛民日记", "山野徒步者", "旅行薯", "摄影笔记", "小众旅行家", "背包客阿泽", "旅途见闻", "风景收集者"];
  return authors[Math.floor(Math.random() * authors.length)];
};

const getRandomLocation = () => {
  const locations = ["浙江·丽水", "福建·平潭", "四川·阿坝", "云南·大理", "青海·茶卡", "安徽·宏村", "新疆·喀纳斯", "广东·海陵岛", "江西·婺源", "贵州·肇兴侗寨"];
  return locations[Math.floor(Math.random() * locations.length)];
};
</script>

<style lang="scss" scoped>
.font-medium {
  font-weight: 500;
}

.recommend-page {
  min-height: 100vh;
  background-color: #f5f5f5;
  overflow-x: hidden;
  font-size: 14px;
  color: #333;

  .search-container {
    position: sticky;
    top: 0;
    z-index: 99;
    background-color: transparent;
    padding: 0 16px 8px;
    transition: all 0.3s ease;

    &.search-focused {
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
    }

    .search-bar {
      display: flex;
      align-items: center;
      padding: 0 16px;
      background-color: #f7f7f7;
      border-radius: 28px;
      height: 44px;
      margin-top: 8px;

      .search-icon {
        margin-right: 10px;
        opacity: 0.7;
      }

      .search-input {
        flex: 1;
        height: 100%;
        font-size: 15px;
        background: transparent;
        border: none;
        outline: none;
        padding: 0;
        color: #111;
      }

      .search-input::placeholder {
        color: #aaa;
        font-size: 15px;
      }

      .clear-icon {
        margin-left: 10px;
        cursor: pointer;
        padding: 4px;
      }

      .search-button {
        font-size: 15px;
        color: #888;
        padding: 4px 12px;
        margin-left: 8px;
        cursor: pointer;
        transition: all 0.2s ease;
      }

      .search-button-active {
        color: #ffa500;
        font-weight: 500;
      }
    }

    .search-panel {
      padding: 8px 16px 16px;
      background-color: transparent;
      border-radius: 0 0 16px 16px;
      max-height: 400px;
      overflow-y: auto;

      .panel-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 12px;
        padding-top: 4px;

        .panel-title {
          font-size: 13px;
          font-weight: 500;
          color: #888;
        }
      }

      .tag-list {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        margin-bottom: 20px;
      }

      .hot-tag {
        display: flex;
        align-items: center;
        background-color: #f7f7f7;
        padding: 7px 14px;
        border-radius: 20px;
        font-size: 14px;
        color: #333;
        cursor: pointer;
        transition: all 0.2s ease;

        .tag-rank {
          display: inline-block;
          width: 18px;
          height: 18px;
          line-height: 18px;
          text-align: center;
          font-size: 11px;
          color: #fff;
          border-radius: 50%;
          margin-right: 8px;
        }

        .rank-1 { background-color: #ff2442; }
        .rank-2 { background-color: #ff7d00; }
        .rank-3 { background-color: #ffb400; }
        .rank-other { background-color: #888; }

        &:active {
          background-color: #eee;
          transform: scale(0.98);
        }
      }
    }
  }

  .content-scroll {
    height: calc(100vh - 110px);
    overflow-y: auto;
  }

  .custom-refresher {
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #f5f5f5;
    transition: height 0.3s ease;

    .refresher-text {
      font-size: 14px;
      color: #ffa500;
      font-weight: 500;
    }
  }

  .top-padding {
    height: 12px;
  }

  .search-result-tip {
    font-size: 14px;
    color: #666;
    padding: 12px 16px;
    background-color: #fff;
    border-radius: 12px;
    margin: 0 16px 12px;
    display: flex;
    align-items: center;

    .tip-icon {
      margin-right: 6px;
    }

    .search-keyword {
      color: #ffa500;
      font-weight: 500;
      margin-left: 4px;
    }
  }

  .empty-state {
    text-align: center;
    padding: 60px 20px;

    .empty-icon {
      margin-bottom: 24px;
    }

    .empty-text {
      display: block;
      font-size: 18px;
      color: #333;
      margin-bottom: 8px;
      font-weight: 500;
    }

    .empty-tip {
      font-size: 14px;
      color: #888;
      margin-bottom: 24px;
    }

    .empty-hot-tags {
      display: flex;
      align-items: center;
      justify-content: flex-start;
      width: 100%;
      padding: 0 16px;

      .tag-label {
        font-size: 14px;
        color: #888;
        margin-right: 10px;
      }

      .tag-scroll {
        display: flex;
        gap: 8px;
        overflow-x: auto;
        padding-bottom: 4px;

        .empty-tag {
          background-color: #f7f7f7;
          padding: 6px 12px;
          border-radius: 16px;
          font-size: 13px;
          color: #333;
          white-space: nowrap;
          cursor: pointer;

          &:active {
            background-color: #eee;
          }
        }
      }
    }
  }

  .note-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
    gap: 14px;
    padding: 0 16px;
  }

  .note-card {
    background-color: #fff;
    border-radius: 16px;
    overflow: hidden;
    box-shadow: 0 3px 12px rgba(0, 0, 0, 0.06);
    transition: all 0.3s ease;
    cursor: pointer;
    display: flex;
    flex-direction: column;
    height: 100%;

    &:active {
      transform: scale(0.98);
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
    }

    .card-cover {
      position: relative;
      width: 100%;
      aspect-ratio: 3/4;
      overflow: hidden;
      border-radius: 16px 16px 0 0;

      .cover-img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.3s ease;
      }

      .img-count {
        position: absolute;
        bottom: 10px;
        right: 10px;
        background-color: rgba(0, 0, 0, 0.6);
        color: #fff;
        font-size: 12px;
        padding: 3px 8px;
        border-radius: 12px;
        display: flex;
        align-items: center;

        .count-text {
          margin-left: 4px;
        }
      }

      .publish-time {
        position: absolute;
        top: 10px;
        right: 10px;
        background-color: rgba(0, 0, 0, 0.6);
        color: #fff;
        font-size: 11px;
        padding: 2px 6px;
        border-radius: 8px;
      }
    }

    .card-content {
      padding: 12px;
      flex: 1;
      display: flex;
      flex-direction: column;
      justify-content: space-between;

      .card-title {
        font-size: 15px;
        color: #111;
        line-height: 1.5;
        margin-bottom: 8px;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
      }

      .card-meta {
        font-size: 12px;
        color: #888;
        margin-bottom: 8px;
        display: flex;
        align-items: center;

        .card-author {
          color: #666;
          margin-right: 4px;
        }

        .meta-separator {
          margin: 0 4px;
          font-size: 10px;
        }

        .card-location {
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
      }

      .card-stats {
        display: flex;
        gap: 12px;

        .stat-item {
          display: flex;
          align-items: center;
          font-size: 11px;
          color: #888;

          .stat-text {
            margin-left: 3px;
          }
        }
      }
    }
  }

  .loading-footer {
    text-align: center;
    padding: 20px 0;
    font-size: 13px;
    color: #888;
    background-color: #f5f5f5;

    .loading-content {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
    }

    .loading-icon {
      animation: spin 1s linear infinite;
    }

    .load-more-text {
      color: #666;
    }

    .no-more-text {
      color: #aaa;
    }
  }

  .bottom-padding {
    height: 20px;
  }
}

@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

@media (max-width: 375px) {
  .recommend-page .note-grid {
    gap: 10px;
    padding: 0 12px;
  }

  .recommend-page .card-content {
    padding: 10px;
  }

  .recommend-page .card-title {
    font-size: 14px;
  }
}

@media (min-width: 768px) {
  .recommend-page {
    max-width: 768px;
    margin: 0 auto;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.05);
  }
}
</style>