<template>
  <view class="login-container pageBg">
    <!-- 顶部Logo -->
    <view class="logo">
      <image src="/static/images/图标.png" mode="widthFix"></image>
    </view>
    
    <!-- 简化表单结构 -->
    <view class="login-form">
      <!-- 账号输入 -->
      <view class="form-item">
        <uni-icons type="person" size="24" color="#808080" class="icon"></uni-icons>
        <input 
          v-model="formData.username" 
          type="text" 
          placeholder="请输入账号" 
          placeholder-class="placeholder"
          maxlength="20"
          class="input-field"
        />
      </view>
      
      <!-- 密码输入 -->
      <view class="form-item">
        <uni-icons type="locked" size="24" color="#808080" class="icon"></uni-icons>
        <input 
          v-model="formData.password" 
          type="password" 
          placeholder="请输入密码" 
          placeholder-class="placeholder"
          maxlength="20"
          class="input-field"
        />
      </view>
      
      <!-- 登录按钮  -->
      <button 
        class="login-btn" 
        @click="handleLogin"
        :disabled="!formData.username.trim() || !formData.password.trim()"
        :loading="loading"
      >
        {{ loading ? '登录中...' : '登录/注册' }}
      </button>
      
      <!-- 其他登录方式 -->
      <view class="other-login">
        <view class="title">其他登录方式</view>
        <view class="icons">
          <uni-icons 
            type="weixin" 
            size="40" 
            color="#07C160" 
            class="other-icon"
            @click="wechatLogin"
          ></uni-icons>
          <uni-icons 
            type="qq" 
            size="40" 
            color="#12B7F5" 
            class="other-icon"
            @click="qqLogin"
          ></uni-icons>
        </view>
      </view>
    </view>
  </view>
</template>

<script setup>
import { ref, reactive } from 'vue';

// 表单数据
const formData = reactive({
  username: '',
  password: ''
});

const loading = ref(false); // 加载状态

// 内置测试账户（模拟数据库已有账户）
const testAccount = {
  username: '123456',
  password: '123456',
  nickname: '爱旅行的小王',
  avatar: '/common/images/头像.jpg',
  phone: '12341234123'
};

// 表单验证
const validateForm = () => {
  // 验证用户名
  if (!formData.username.trim()) {
    uni.showToast({ title: '请输入账号', icon: 'none' });
    return false;
  }
  
  if (formData.username.length < 3 || formData.username.length > 20) {
    uni.showToast({ title: '账号长度需3-20字符', icon: 'none' });
    return false;
  }
  
  // 验证密码
  if (!formData.password.trim()) {
    uni.showToast({ title: '请输入密码', icon: 'none' });
    return false;
  }
  
  if (formData.password.length < 6 || formData.password.length > 20) {
    uni.showToast({ title: '密码长度需6-20字符', icon: 'none' });
    return false;
  }
  
  return true;
};

// 登录/注册逻辑
const handleLogin = () => {
  // 表单验证
  if (!validateForm()) {
    return;
  }
  
  loading.value = true;
  
  // TODO: 连接后端登录接口
  // 实际开发中替换为真实的API调用
  // const response = await uni.request({
  //   url: 'https://your-api-domain.com/api/login',
  //   method: 'POST',
  //   data: {
  //     username: formData.username,
  //     password: formData.password
  //   }
  // });
  
  // 模拟接口请求
  setTimeout(() => {
    let userInfo = null;
    
    // TODO: 实际开发中根据接口返回处理
    // 匹配测试账户：直接登录
    if (formData.username === testAccount.username && formData.password === testAccount.password) {
      userInfo = testAccount;
      uni.showToast({ title: '登录成功', icon: 'success' });
    } else {
      // TODO: 连接后端注册接口
      // 新用户：自动注册
      // const registerResponse = await uni.request({
      //   url: 'https://your-api-domain.com/api/register',
      //   method: 'POST',
      //   data: {
      //     username: formData.username,
      //     password: formData.password
      //   }
      // });
      
      userInfo = {
        username: formData.username,
        password: formData.password,
        nickname: `用户${formData.username.slice(-4)}`,
        avatar: '/common/images/头像.jpg',
        phone: ''
      };
      uni.showToast({ title: '注册并登录成功', icon: 'success' });
    }
    
    // 存储用户信息到缓存
    uni.setStorageSync('userInfo', userInfo);
    loading.value = false;
    
    // 跳转到tabBar首页
    uni.switchTab({ url: '/pages/index/index' });
  }, 1000);
};

// 微信登录
const wechatLogin = () => {
  // TODO: 连接微信登录接口
  uni.showLoading({ title: '微信登录中...' });
  setTimeout(() => {
    const userInfo = {
      username: 'wechat_' + Math.random().toString(36).slice(-8),
      nickname: '微信用户',
      avatar: '/common/images/wechat-avatar.png',
      phone: ''
    };
    uni.setStorageSync('userInfo', userInfo);
    uni.hideLoading();
    uni.showToast({ title: '微信登录成功', icon: 'success' });
    uni.switchTab({ url: '/pages/index/index' });
  }, 1000);
};

// QQ登录
const qqLogin = () => {
  // TODO: 连接QQ登录接口
  uni.showToast({ title: '暂未开通QQ登录', icon: 'none' });
};
</script>

<style lang="scss">
.login-container {
  padding: 80rpx 40rpx;
  min-height: 100vh;
  box-sizing: border-box;
  background: linear-gradient(135deg, #fff9e6 0%, #fff0cc 100%);
  
  .logo {
    display: flex;
    justify-content: center;
    margin-bottom: 80rpx;
    image {
      width: 200rpx;
      height: auto;
    }
  }
  
  .login-form {
    .form-item {
      display: flex;
      align-items: center;
      border: 1px solid #ffd166;
      border-radius: 12rpx;
      padding: 0 20rpx;
      margin-bottom: 30rpx;
      height: 90rpx;
      background: #fff;
      box-shadow: 0 2rpx 10rpx rgba(255, 193, 7, 0.1);
      
      .icon {
        margin-right: 20rpx;
        flex-shrink: 0;
      }
      
      .input-field {
        flex: 1;
        height: 100%;
        font-size: 32rpx;
        color: #333;
        background: transparent;
        border: none;
        outline: none;
      }
      
      .placeholder {
        color: #aaa;
        font-size: 30rpx;
      }
    }
    
    .login-btn {
      width: 100%;
      height: 90rpx;
      line-height: 90rpx;
      background: linear-gradient(135deg, #ffb300 0%, #ff8f00 100%);
      color: #fff;
      border-radius: 12rpx;
      font-size: 34rpx;
      font-weight: bold;
      margin-bottom: 20rpx;
      border: none;
      box-shadow: 0 4rpx 15rpx rgba(255, 179, 0, 0.3);
      transition: all 0.3s;
      
      &:active {
        transform: translateY(2rpx);
        box-shadow: 0 2rpx 8rpx rgba(255, 179, 0, 0.3);
      }
    }
    
    .login-btn:disabled {
      background: #ffe0b2;
      color: #fff;
      box-shadow: none;
    }
    
    .other-login {
      display: flex;
      flex-direction: column;
      align-items: center;
      margin-top: 60rpx;
      
      .title {
        font-size: 28rpx;
        color: #999;
        margin-bottom: 30rpx;
        position: relative;
        
        &:before, &:after {
          content: '';
          position: absolute;
          top: 50%;
          width: 80rpx;
          height: 1rpx;
          background: #eee;
        }
        
        &:before {
          left: -100rpx;
        }
        
        &:after {
          right: -100rpx;
        }
      }
      
      .icons {
        display: flex;
        gap: 60rpx;
        
        .other-icon {
          cursor: pointer;
          transition: transform 0.3s;
          
          &:active {
            transform: scale(0.9);
          }
        }
      }
    }
  }
}
</style>