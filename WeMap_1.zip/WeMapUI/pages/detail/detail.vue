<template>
  <view class="detail-page">
    <!-- 顶部导航栏 -->
    <view class="nav-bar" :class="{ 'nav-scroll': isNavScrolled }">
      <view class="nav-back" @click="goBack">
        <uni-icons type="left" size="24" :color="isNavScrolled ? '#333' : '#fff'" />
      </view>
      <text class="nav-title" :style="{ color: isNavScrolled ? '#333' : '#fff' }">
        {{ isNavScrolled ? noteInfo.title : '笔记详情' }}
      </text>
      <view class="nav-share" @click="showShareToast">
        <uni-icons type="share" size="24" :color="isNavScrolled ? '#333' : '#fff'" />
      </view>
    </view>

    <!-- 内容主体 -->
    <scroll-view 
      class="content-scroll" 
      scroll-y
      @scroll="handleScroll"
      scroll-with-animation
    >
      <!-- 图片区域 - 轮播图 -->
      <view class="image-carousel">
        <swiper 
          class="carousel-swiper" 
          :indicator-dots="noteInfo.images.length > 1"
          indicator-color="rgba(255,255,255,0.5)"
          indicator-active-color="#fff"
          :autoplay="false"
          :duration="300"
          :circular="noteInfo.images.length > 1"
          @change="onSwiperChange"
        >
          <swiper-item 
            v-for="(img, idx) in noteInfo.images" 
            :key="idx"
            class="carousel-item"
          >
            <view class="image-wrapper" @click="previewImage(idx)">
              <image 
                :src="img" 
                class="carousel-image" 
                mode="aspectFill" 
                lazy-load
                @load="onImageLoad"
              />
              <!-- 图片加载指示器 -->
              <view class="image-loading" v-if="!imageLoaded[idx]">
                <uni-icons type="spinner-cycle" size="28" color="#fff" />
              </view>
            </view>
          </swiper-item>
        </swiper>
        
        <!-- 自定义指示器（更美观） -->
        <view class="custom-indicator" v-if="noteInfo.images.length > 1">
          <text class="indicator-text">{{ currentImageIndex + 1 }}/{{ noteInfo.images.length }}</text>
        </view>
      </view>

      <!-- 核心内容区 -->
      <view class="core-content">
        <!-- 作者信息 -->
        <view class="author-section">
          <view class="author-main">
            <image :src="authorAvatar" class="author-avatar" mode="aspectFill" />
            <view class="author-info">
              <text class="author-name">{{ noteInfo.author }}</text>
              <text class="publish-time">{{ noteInfo.publishTime }} · {{ noteInfo.location }}</text>
            </view>
            <button class="follow-btn" :class="{ 'followed': isFollowed }" @click="toggleFollow">
              {{ isFollowed ? '已关注' : '关注' }}
            </button>
          </view>
        </view>

        <!-- 笔记内容 -->
        <view class="content-section">
          <text class="note-title">{{ noteInfo.title }}</text>
          
          <view class="note-desc">
            <text class="desc-text">{{ noteDesc }}</text>
          </view>

          <!-- 话题标签 -->
          <view class="topic-section" v-if="topicTags.length > 0">
            <text 
              class="topic-tag" 
              v-for="(tag, idx) in topicTags" 
              :key="idx"
              @click="searchByTag(tag)"
            >
              #{{ tag }}
            </text>
          </view>

          <!-- 坐标信息显示（新增，使用虚构坐标） -->
          <view class="location-coordinate" v-if="noteInfo.coordinate">
            <uni-icons type="map-pin" size="14" color="#ff6b6b" />
            <text class="coordinate-text">
              {{ noteInfo.location }} 具体坐标：{{ formatCoordinate(noteInfo.coordinate) }}
            </text>
          </view>

          <!-- 互动数据 -->
          <view class="stats-section">
            <view class="stat-item">
              <uni-icons type="heart" size="16" color="#ff2442" />
              <text class="stat-text">{{ formatNum(noteInfo.likes) }}人点赞</text>
            </view>
            <view class="stat-item">
              <uni-icons type="eye" size="16" color="#666" />
              <text class="stat-text">{{ formatNum(noteInfo.views || 1520) }}次浏览</text>
            </view>
            <view class="stat-item">
              <uni-icons type="star" size="16" color="#ffb400" />
              <text class="stat-text">{{ formatNum(noteInfo.collects) }}人收藏</text>
            </view>
            <view class="stat-item">
              <uni-icons type="chatbubble" size="16" color="#666" />
              <text class="stat-text">{{ formatNum(noteInfo.comments) }}条评论</text>
            </view>
          </view>
        </view>

        <!-- 精简的右侧操作栏（只保留点赞和收藏） -->
        <view class="simple-actions">
          <view class="action-item like-action" @click="toggleLike" :class="{ 'active': isLiked }">
            <uni-icons 
              :type="isLiked ? 'heart-filled' : 'heart'" 
              :color="isLiked ? '#ff2442' : '#333'" 
              size="28" 
            />
            <text class="action-text">{{ formatNum(noteInfo.likes) }}</text>
          </view>
          
          <view class="action-item collect-action" @click="toggleCollect" :class="{ 'active': isCollected }">
            <uni-icons 
              :type="isCollected ? 'star-filled' : 'star'" 
              :color="isCollected ? '#ffb400' : '#333'" 
              size="28" 
            />
            <text class="action-text">{{ formatNum(noteInfo.collects) }}</text>
          </view>
        </view>
      </view>

      <!-- 评论区 -->
      <view class="comment-section" id="commentSection">
        <view class="section-header">
          <text class="section-title">评论</text>
          <text class="comment-count">{{ formatNum(noteInfo.comments) }}</text>
        </view>

        <!-- 评论排序 -->
        <view class="sort-tabs">
          <text 
            class="sort-tab" 
            :class="{ 'active': sortType === 'hot' }" 
            @click="sortType = 'hot'"
          >
            最热
          </text>
          <text 
            class="sort-tab" 
            :class="{ 'active': sortType === 'new' }" 
            @click="sortType = 'new'"
          >
            最新
          </text>
        </view>

        <!-- 评论输入框 -->
        <view class="comment-input-container">
          <image :src="userAvatar" class="user-avatar" mode="aspectFill" />
          <view class="input-wrapper">
            <input 
              type="text" 
              v-model="commentInput" 
              placeholder="说点什么..." 
              class="comment-input"
              maxlength="200"
            />
            <text 
              class="send-btn" 
              :class="{ 'active': commentInput.trim() }" 
              @click="sendComment"
            >
              发布
            </text>
          </view>
        </view>

        <!-- 评论列表 -->
        <view class="comment-list">
          <view 
            class="comment-item" 
            v-for="(item, index) in sortedCommentList" 
            :key="item.id"
            :class="{ 'has-reply': item.replies && item.replies.length > 0 }"
          >
            <image :src="item.avatar" class="comment-avatar" mode="aspectFill" />
            
            <view class="comment-main">
              <view class="comment-header">
                <text class="comment-username">{{ item.username }}</text>
                <text class="comment-time">{{ item.time }}</text>
              </view>
              
              <text class="comment-content">{{ item.content }}</text>
              
              <view class="comment-actions">
                <view class="action-left">
                  <text class="like-action" @click="likeComment(item.id)">
                    <uni-icons 
                      :type="item.isLiked ? 'heart-filled' : 'heart'" 
                      :color="item.isLiked ? '#ff2442' : '#999'" 
                      size="14" 
                    />
                    {{ item.likes > 0 ? formatNum(item.likes) : '赞' }}
                  </text>
                </view>
                <view class="action-right">
                  <!-- 删除评论按钮（只对自己的评论显示） -->
                  <text 
                    class="delete-action" 
                    v-if="item.username === '我'" 
                    @click="deleteComment(item.id)"
                  >
                    删除
                  </text>
                  <text class="reply-action" @click="toggleReplyInput(item.id)">
                    {{ replyTargetId === item.id ? '取消' : '回复' }}
                  </text>
                </view>
              </view>

              <!-- 回复列表 -->
              <view class="reply-list" v-if="item.replies && item.replies.length > 0">
                <view class="reply-item" v-for="(reply, rIdx) in item.replies" :key="reply.id">
                  <view class="reply-content">
                    <text class="reply-username">{{ reply.username }}：</text>
                    <text class="reply-text">{{ reply.content }}</text>
                  </view>
                  <view class="reply-actions">
                    <text class="reply-like" @click="likeReply(item.id, reply.id)">
                      <uni-icons 
                        :type="reply.isLiked ? 'heart-filled' : 'heart'" 
                        :color="reply.isLiked ? '#ff2442' : '#ccc'" 
                        size="12" 
                      />
                      {{ reply.likes || '' }}
                    </text>
                    <!-- 删除回复按钮（只对自己的回复显示） -->
                    <text 
                      class="delete-reply" 
                      v-if="reply.username === '我'" 
                      @click="deleteReply(item.id, reply.id)"
                    >
                      删除
                    </text>
                  </view>
                </view>
              </view>

              <!-- 回复输入框 -->
              <view class="reply-input-container" v-if="replyTargetId === item.id">
                <input 
                  type="text" 
                  v-model="replyInput" 
                  :placeholder="`回复 @${item.username}`" 
                  class="reply-input"
                  maxlength="100"
                />
                <text class="reply-send" @click="sendReply(item.id)">发送</text>
              </view>
            </view>
          </view>
        </view>

        <!-- 加载更多 -->
        <view class="load-more" v-if="commentList.length > 0">
          <text class="load-text">— 没有更多评论了 —</text>
        </view>
      </view>

      <!-- 底部安全区域 -->
      <view class="bottom-safe-area"></view>
    </scroll-view>
  </view>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';
import { useRoute, useRouter } from 'vue-router';

// 路由实例
const route = useRoute();
const router = useRouter();

// 核心状态 - 使用虚构的小众景点数据
const noteInfo = ref({
  id: '',
  title: '杭州·云栖竹径小众秘境',
  images: [
    "https://picsum.photos/seed/bamboo1/800/1000",
    "https://picsum.photos/seed/bamboo2/800/1000",
    "https://picsum.photos/seed/bamboo3/800/1000"
  ],
  author: '山林旅人',
  location: '杭州·云栖竹径',
  publishTime: '5天前',
  likes: 356,
  collects: 289,
  comments: 64,
  views: 3280,
  coordinate: '120.098765,30.256789' // 虚构的杭州云栖竹径附近小众景点坐标
});

// 图片相关状态
const currentImageIndex = ref(0);
const imageLoaded = ref({}); // 记录图片加载状态

// 模拟数据
const authorAvatar = ref('https://picsum.photos/seed/mountain/100/100');
const userAvatar = ref('https://picsum.photos/seed/user/100/100');
const topicTags = ref([]);
const isNavScrolled = ref(false);
const isLiked = ref(false);
const isCollected = ref(false);
const isFollowed = ref(false);
const commentInput = ref('');
const replyInput = ref('');
const replyTargetId = ref(null);
const sortType = ref('hot');

// 笔记详情描述（匹配虚构景点）
const noteDesc = computed(() => {
  return `${noteInfo.value.title} 藏在西湖西南侧的山谷中，是杭州少有人知的清幽秘境～

🌿 核心亮点：千年竹林、溪流潺潺、负氧离子爆棚、无商业化打扰
📍 具体位置：${noteInfo.value.location} 后山小径
⏰ 最佳时间：春季（4-5月）竹笋冒尖，秋季（10-11月）竹叶金黄
🚗 交通方式：公交324路直达云栖竹径站，步行15分钟可达
💡 旅行Tips：
1. 穿浅色或汉服拍照超出片，竹林光影绝美
2. 建议工作日前往，周末人稍多
3. 自带饮用水，沿途无小卖部
4. 步行路线平缓，适合亲子和老人`;
});

// 生成唯一ID的函数
const generateId = () => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

// 模拟评论数据（匹配虚构景点）
const commentList = ref([
  {
    id: generateId(),
    avatar: 'https://picsum.photos/seed/travel1/100/100',
    username: '竹林深处',
    time: '3天前',
    content: '上周刚去过！按照坐标找过去的，真的人超少，竹林里特别凉快，拍照根本不用修图～',
    likes: 42,
    isLiked: false,
    replies: [
      {
        id: generateId(),
        username: noteInfo.value.author,
        content: '是的！这个坐标是后山的小众入口，比正门人少太多啦～',
        likes: 16,
        isLiked: false
      }
    ]
  },
  {
    id: generateId(),
    avatar: 'https://picsum.photos/seed/travel2/100/100',
    username: '摄影喵',
    time: '2天前',
    content: '坐标太准了！跟着导航直接到了最佳拍摄点，早上9点的阳光透过竹林的光影绝了～',
    likes: 35,
    isLiked: false,
    replies: []
  },
  {
    id: generateId(),
    avatar: 'https://picsum.photos/seed/travel3/100/100',
    username: '杭州土著',
    time: '1天前',
    content: '作为杭州人，居然不知道这个小众入口！按照坐标找过去，发现了新大陆，感谢分享～',
    likes: 58,
    isLiked: false,
    replies: [
      {
        id: generateId(),
        username: '我',
        content: '请问从坐标点进去需要门票吗？',
        likes: 7,
        isLiked: false
      },
      {
        id: generateId(),
        username: noteInfo.value.author,
        content: '不需要哦！是免费的后山小径，直接进去就行～',
        likes: 12,
        isLiked: false
      }
    ]
  }
]);

// 排序后的评论列表
const sortedCommentList = computed(() => {
  const copyList = [...commentList.value];
  if (sortType.value === 'hot') {
    return copyList.sort((a, b) => b.likes - a.likes);
  } else {
    const timeMap = { '刚刚': 3, '1天前': 2, '2天前': 1, '3天前': 0 };
    return copyList.sort((a, b) => timeMap[b.time] - timeMap[a.time]);
  }
});

// 页面加载初始化
onMounted(() => {
  // TODO: 接口调用 - 获取笔记详情数据
  // fetchNoteDetail(route.query.id || route.params.id);
  
  // TODO: 接口调用 - 获取评论列表
  // fetchCommentList(route.query.id || route.params.id);
  
  // TODO: 接口调用 - 获取用户是否点赞/收藏/关注状态
  // fetchUserInteractionStatus(route.query.id || route.params.id);
  
  generateTopicTags();
});

// 辅助函数
const generateTopicTags = () => {
  const baseTags = [
    '杭州旅行', '小众秘境', '竹林拍照', '周末去哪儿',
    noteInfo.value.location.split('·')[0] + '小众游',
    '徒步路线', '免费景点'
  ];
  topicTags.value = [...new Set(baseTags)].slice(0, 4);
};

const formatNum = (num) => num >= 10000 ? (num / 10000).toFixed(1) + '万' : num;

// 格式化坐标显示（虚构坐标将显示为：120.0988° E, 30.2568° N）
const formatCoordinate = (coordinate) => {
  if (!coordinate) return '';
  
  const [lng, lat] = coordinate.split(',').map(Number);
  if (isNaN(lng) || isNaN(lat)) return coordinate;
  
  // 保留4位小数，添加经纬度标识
  const formattedLng = lng.toFixed(4) + '° E';
  const formattedLat = lat.toFixed(4) + '° N';
  return `${formattedLng}, ${formattedLat}`;
};

// 图片相关函数
const onSwiperChange = (e) => {
  currentImageIndex.value = e.detail.current;
};

const onImageLoad = (e) => {
  const index = currentImageIndex.value;
  imageLoaded.value[index] = true;
};

// 事件处理函数
const handleScroll = (e) => {
  const scrollTop = e.detail.scrollTop;
  isNavScrolled.value = scrollTop > 200;
};

const goBack = () => {
  uni.navigateBack();
};

const previewImage = (currentIdx) => {
  uni.previewImage({
    urls: noteInfo.value.images,
    current: currentIdx,
    loop: true,
    indicator: 'number'
  });
};

// 点赞切换 - 需要接口
const toggleLike = () => {
  if (isLiked.value) {
    // TODO: 接口调用 - 取消点赞
    // cancelLikeNote(noteInfo.value.id).then(() => {
      noteInfo.value.likes = Math.max(0, noteInfo.value.likes - 1);
      uni.showToast({ title: '取消点赞', icon: 'none' });
    // });
  } else {
    // TODO: 接口调用 - 点赞笔记
    // likeNote(noteInfo.value.id).then(() => {
      noteInfo.value.likes += 1;
      uni.showToast({ title: '点赞成功', icon: 'none' });
    // });
  }
  isLiked.value = !isLiked.value;
};

// 收藏切换 - 需要接口
const toggleCollect = () => {
  if (isCollected.value) {
    // TODO: 接口调用 - 取消收藏
    // cancelCollectNote(noteInfo.value.id).then(() => {
      noteInfo.value.collects = Math.max(0, noteInfo.value.collects - 1);
      uni.showToast({ title: '取消收藏', icon: 'none' });
    // });
  } else {
    // TODO: 接口调用 - 收藏笔记
    // collectNote(noteInfo.value.id).then(() => {
      noteInfo.value.collects += 1;
      uni.showToast({ title: '收藏成功', icon: 'none' });
    // });
  }
  isCollected.value = !isCollected.value;
};

// 关注作者 - 需要接口
const toggleFollow = () => {
  // TODO: 接口调用 - 关注/取消关注作者
  // toggleFollowAuthor(noteInfo.value.authorId).then(() => {
    isFollowed.value = !isFollowed.value;
    uni.showToast({ title: isFollowed.value ? '已关注作者' : '取消关注', icon: 'none' });
  // });
};

const searchByTag = (tag) => {
  uni.showToast({ title: `搜索: ${tag}`, icon: 'none' });
};

// 发布评论 - 需要接口
const sendComment = () => {
  const content = commentInput.value.trim();
  if (!content) return;

  // TODO: 接口调用 - 发布评论
  // addComment(noteInfo.value.id, content).then((newComment) => {
    commentList.value.unshift({
      id: generateId(),
      avatar: userAvatar.value,
      username: '我',
      time: '刚刚',
      content,
      likes: 0,
      isLiked: false,
      replies: []
    });
    noteInfo.value.comments++;
    commentInput.value = '';
    uni.showToast({ title: '评论成功', icon: 'success' });
  // }).catch(err => {
  //   uni.showToast({ title: '评论失败', icon: 'error' });
  // });
};

// 点赞评论 - 需要接口
const likeComment = (commentId) => {
  const comment = commentList.value.find(item => item.id === commentId);
  if (comment) {
    // TODO: 接口调用 - 点赞/取消点赞评论
    // likeCommentApi(commentId).then(() => {
      comment.isLiked = !comment.isLiked;
      comment.likes = comment.isLiked ? comment.likes + 1 : Math.max(0, comment.likes - 1);
    // });
  }
};

// 使用ID而不是索引来显示回复输入框
const toggleReplyInput = (commentId) => {
  replyTargetId.value = replyTargetId.value === commentId ? null : commentId;
  replyInput.value = '';
};

// 发布回复 - 需要接口
const sendReply = (commentId) => {
  const content = replyInput.value.trim();
  if (!content) return;

  const comment = commentList.value.find(item => item.id === commentId);
  if (comment) {
    // TODO: 接口调用 - 回复评论
    // addReply(commentId, content).then((newReply) => {
      if (!comment.replies) {
        comment.replies = [];
      }
      
      comment.replies.push({
        id: generateId(),
        username: '我',
        content,
        likes: 0,
        isLiked: false
      });
      replyInput.value = '';
      replyTargetId.value = null;
    // });
  }
};

// 点赞回复 - 需要接口
const likeReply = (commentId, replyId) => {
  const comment = commentList.value.find(item => item.id === commentId);
  if (comment && comment.replies) {
    const reply = comment.replies.find(r => r.id === replyId);
    if (reply) {
      // TODO: 接口调用 - 点赞/取消点赞回复
      // likeReplyApi(commentId, replyId).then(() => {
        reply.isLiked = !reply.isLiked;
        reply.likes = reply.isLiked ? (reply.likes || 0) + 1 : Math.max(0, (reply.likes || 0) - 1);
      // });
    }
  }
};

// 删除评论 - 需要接口
const deleteComment = (commentId) => {
  uni.showModal({
    title: '确认删除',
    content: '确定要删除这条评论吗？',
    confirmColor: '#ff2442',
    success: (res) => {
      if (res.confirm) {
        // TODO: 接口调用 - 删除评论
        // deleteCommentApi(commentId).then(() => {
          const index = commentList.value.findIndex(item => item.id === commentId);
          if (index !== -1) {
            commentList.value.splice(index, 1);
            noteInfo.value.comments = Math.max(0, noteInfo.value.comments - 1);
            uni.showToast({ title: '删除成功', icon: 'success' });
          }
        // });
      }
    }
  });
};

// 删除回复 - 需要接口
const deleteReply = (commentId, replyId) => {
  uni.showModal({
    title: '确认删除',
    content: '确定要删除这条回复吗？',
    confirmColor: '#ff2442',
    success: (res) => {
      if (res.confirm) {
        // TODO: 接口调用 - 删除回复
        // deleteReplyApi(commentId, replyId).then(() => {
          const comment = commentList.value.find(item => item.id === commentId);
          if (comment && comment.replies) {
            const replyIndex = comment.replies.findIndex(r => r.id === replyId);
            if (replyIndex !== -1) {
              comment.replies.splice(replyIndex, 1);
              uni.showToast({ title: '删除成功', icon: 'success' });
            }
          }
        // });
      }
    }
  });
};

// 分享功能 - 需要接口
const showShareToast = () => {
  // TODO: 接口调用 - 记录分享行为
  // recordShare(noteInfo.value.id).then(() => {
    uni.showToast({ title: '分享成功', icon: 'success' });
  // });
  
  // 实际分享功能
  // uni.share({
  //   provider: 'weixin',
  //   scene: 'WXSceneSession',
  //   type: 0,
  //   title: noteInfo.value.title,
  //   summary: noteDesc.value.substring(0, 100),
  //   imageUrl: noteInfo.value.images[0],
  //   href: window.location.href,
  //   success: function (res) {
  //     console.log('分享成功');
  //   },
  //   fail: function (err) {
  //     console.log('分享失败', err);
  //   }
  // });
};

// TODO: 需要新增的接口函数示例
/*
// 获取笔记详情
const fetchNoteDetail = async (noteId) => {
  try {
    const response = await uni.request({
      url: `/api/notes/${noteId}`,
      method: 'GET'
    });
    noteInfo.value = response.data;
  } catch (error) {
    console.error('获取笔记详情失败', error);
  }
};

// 获取评论列表
const fetchCommentList = async (noteId) => {
  try {
    const response = await uni.request({
      url: `/api/notes/${noteId}/comments`,
      method: 'GET',
      data: { sort: sortType.value }
    });
    commentList.value = response.data;
  } catch (error) {
    console.error('获取评论列表失败', error);
  }
};

// 获取用户互动状态
const fetchUserInteractionStatus = async (noteId) => {
  try {
    const response = await uni.request({
      url: `/api/notes/${noteId}/interaction-status`,
      method: 'GET'
    });
    const { isLiked: liked, isCollected: collected, isFollowed: followed } = response.data;
    isLiked.value = liked;
    isCollected.value = collected;
    isFollowed.value = followed;
  } catch (error) {
    console.error('获取用户互动状态失败', error);
  }
};

// 点赞笔记
const likeNote = async (noteId) => {
  return uni.request({
    url: `/api/notes/${noteId}/like`,
    method: 'POST'
  });
};

// 取消点赞笔记
const cancelLikeNote = async (noteId) => {
  return uni.request({
    url: `/api/notes/${noteId}/like`,
    method: 'DELETE'
  });
};

// 收藏笔记
const collectNote = async (noteId) => {
  return uni.request({
    url: `/api/notes/${noteId}/collect`,
    method: 'POST'
  });
};

// 取消收藏笔记
const cancelCollectNote = async (noteId) => {
  return uni.request({
    url: `/api/notes/${noteId}/collect`,
    method: 'DELETE'
  });
};

// 关注作者
const followAuthor = async (authorId) => {
  return uni.request({
    url: `/api/authors/${authorId}/follow`,
    method: 'POST'
  });
};

// 取消关注作者
const unfollowAuthor = async (authorId) => {
  return uni.request({
    url: `/api/authors/${authorId}/follow`,
    method: 'DELETE'
  });
};

// 发布评论
const addComment = async (noteId, content) => {
  return uni.request({
    url: `/api/notes/${noteId}/comments`,
    method: 'POST',
    data: { content }
  });
};

// 点赞评论
const likeCommentApi = async (commentId) => {
  return uni.request({
    url: `/api/comments/${commentId}/like`,
    method: 'POST'
  });
};

// 回复评论
const addReply = async (commentId, content) => {
  return uni.request({
    url: `/api/comments/${commentId}/replies`,
    method: 'POST',
    data: { content }
  });
};

// 点赞回复
const likeReplyApi = async (commentId, replyId) => {
  return uni.request({
    url: `/api/comments/${commentId}/replies/${replyId}/like`,
    method: 'POST'
  });
};

// 删除评论
const deleteCommentApi = async (commentId) => {
  return uni.request({
    url: `/api/comments/${commentId}`,
    method: 'DELETE'
  });
};

// 删除回复
const deleteReplyApi = async (commentId, replyId) => {
  return uni.request({
    url: `/api/comments/${commentId}/replies/${replyId}`,
    method: 'DELETE'
  });
};

// 记录分享
const recordShare = async (noteId) => {
  return uni.request({
    url: `/api/notes/${noteId}/share`,
    method: 'POST'
  });
};
*/
</script>

<style lang="scss" scoped>
.detail-page {
  min-height: 100vh;
  background-color: #fff;
  overflow-x: hidden;

  // 导航栏
  .nav-bar {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 12px 16px;
    background: transparent;
    z-index: 999;
    transition: all 0.3s ease;

    .nav-back, .nav-share {
      width: 44px;
      height: 44px;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
    }

    .nav-title {
      font-size: 17px;
      font-weight: 600;
      transition: color 0.3s ease;
      max-width: 60%;
      text-align: center;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    &.nav-scroll {
      background: rgba(255, 255, 255, 0.95);
      backdrop-filter: blur(10px);
      box-shadow: 0 1px 10px rgba(0, 0, 0, 0.08);
    }
  }

  // 滚动容器
  .content-scroll {
    height: 100vh;
    overflow-y: auto;
    -webkit-overflow-scrolling: touch;
  }

  // 图片轮播区域（匹配竹林主题）
  .image-carousel {
    position: relative;
    width: 100%;
    height: 75vh;
    background-color: #000;
    
    .carousel-swiper {
      width: 100%;
      height: 100%;
      
      .carousel-item {
        display: flex;
        justify-content: center;
        align-items: center;
        
        .image-wrapper {
          position: relative;
          width: 100%;
          height: 100%;
          display: flex;
          justify-content: center;
          align-items: center;
          
          .carousel-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
          }
          
          .image-loading {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            display: flex;
            justify-content: center;
            align-items: center;
          }
        }
      }
    }
    
    .custom-indicator {
      position: absolute;
      bottom: 20px;
      right: 20px;
      background: rgba(0, 0, 0, 0.6);
      padding: 6px 12px;
      border-radius: 16px;
      
      .indicator-text {
        font-size: 14px;
        color: #fff;
        font-weight: 500;
      }
    }
  }

  // 核心内容区
  .core-content {
    position: relative;
    padding: 0;
  }

  // 作者区域
  .author-section {
    padding: 16px;
    border-bottom: 1px solid #f5f5f5;

    .author-main {
      display: flex;
      align-items: center;
      gap: 12px;

      .author-avatar {
        width: 44px;
        height: 44px;
        border-radius: 50%;
        border: 1px solid #f2f2f2;
      }

      .author-info {
        flex: 1;
        
        .author-name {
          display: block;
          font-size: 16px;
          font-weight: 600;
          color: #333;
          margin-bottom: 2px;
        }
        
        .publish-time {
          font-size: 13px;
          color: #999;
        }
      }

      .follow-btn {
        padding: 6px 16px;
        border-radius: 20px;
        font-size: 14px;
        font-weight: 500;
        background: linear-gradient(45deg, #ffb400, #fff8dc);
        color: #fff;
        border: none;
        
        &.followed {
          background: #f8f8f8;
          color: #666;
        }
      }
    }
  }

  // 内容区域
  .content-section {
    padding: 16px;

    .note-title {
      font-size: 20px;
      font-weight: 700;
      color: #333;
      line-height: 1.4;
      margin-bottom: 12px;
      display: block;
    }

    .note-desc {
      margin-bottom: 16px;
      
      .desc-text {
        font-size: 16px;
        color: #333;
        line-height: 1.6;
        white-space: pre-line;
      }
    }

    .topic-section {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      margin-bottom: 16px;
      
      .topic-tag {
        font-size: 14px;
        color: #ffa500;
        background: #fff8dc;
        padding: 6px 12px;
        border-radius: 16px;
        cursor: pointer;
        
        &:active {
          background: #d4ffee;
        }
      }
    }

    // 坐标信息样式（优化显示效果）
    .location-coordinate {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 14px 16px;
      margin-bottom: 16px;
      font-size: 15px;
      border-radius: 12px;
      background: linear-gradient(135deg, #fff8dc 0%, #fff8dc 100%);
      border: 1px solid #fff8dc;
      
      .coordinate-text {
        line-height: 1.5;
        color: #ffa500;
        font-weight: 500;
      }
    }

    .stats-section {
      display: flex;
      flex-wrap: wrap;
      gap: 16px;
      padding: 16px 0;
      border-top: 1px solid #f5f5f5;
      
      .stat-item {
        display: flex;
        align-items: center;
        gap: 6px;
        
        .stat-text {
          font-size: 13px;
          color: #666;
        }
      }
    }
  }

  // 精简右侧操作栏（只保留点赞和收藏）
  .simple-actions {
    position: fixed;
    right: 16px;
    bottom: 120px;
    display: flex;
    flex-direction: column;
    gap: 16px;
    z-index: 99;
    
    .action-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 6px;
      padding: 12px;
      border-radius: 24px;
      background: rgba(255, 255, 255, 0.9);
      backdrop-filter: blur(10px);
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
      cursor: pointer;
      transition: all 0.3s ease;
      
      &.like-action.active {
        background: #fff5f7;
        
        .action-text {
          color: #ff2442;
        }
      }
      
      &.collect-action.active {
        background: #fffaf0;
        
        .action-text {
          color: #ffb400;
        }
      }
      
      .action-text {
        font-size: 12px;
        color: #666;
        font-weight: 600;
        transition: color 0.3s ease;
      }
      
      &:active {
        transform: scale(0.95);
      }
    }
  }

  // 评论区
  .comment-section {
    padding: 0 16px 30px;
    background: #fafafa;
    border-radius: 20px 20px 0 0;
    margin-top: -20px;
    position: relative;
    z-index: 2;

    .section-header {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 20px 0 16px;
      
      .section-title {
        font-size: 18px;
        font-weight: 700;
        color: #333;
      }
      
      .comment-count {
        font-size: 14px;
        color: #999;
      }
    }

    .sort-tabs {
      display: flex;
      gap: 20px;
      margin-bottom: 16px;
      padding-bottom: 12px;
      border-bottom: 1px solid #f0f0f0;
      
      .sort-tab {
        font-size: 14px;
        color: #999;
        padding: 4px 0;
        cursor: pointer;
        
        &.active {
          color: #333;
          font-weight: 600;
          position: relative;
          
          &::after {
            content: '';
            position: absolute;
            bottom: -13px;
            left: 0;
            width: 100%;
            height: 2px;
            background: #333;
            border-radius: 1px;
          }
        }
      }
    }

    .comment-input-container {
      display: flex;
      align-items: center;
      gap: 12px;
      background: #fff;
      border-radius: 20px;
      padding: 12px 16px;
      margin-bottom: 20px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
      
      .user-avatar {
        width: 36px;
        height: 36px;
        border-radius: 50%;
      }
      
      .input-wrapper {
        flex: 1;
        display: flex;
        align-items: center;
        gap: 12px;
        
        .comment-input {
          flex: 1;
          background: transparent;
          border: none;
          outline: none;
          font-size: 16px;
          color: #333;
        }
        
        .send-btn {
          font-size: 15px;
          color: #ccc;
          font-weight: 500;
          
          &.active {
            color: #ffa500;
            cursor: pointer;
          }
        }
      }
    }

    .comment-list {
      display: flex;
      flex-direction: column;
      gap: 20px;
    }

    .comment-item {
      display: flex;
      gap: 12px;
      
      &.has-reply {
        padding-bottom: 16px;
        border-bottom: 1px solid #f5f5f5;
      }
      
      .comment-avatar {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        flex-shrink: 0;
      }
      
      .comment-main {
        flex: 1;
      }
      
      .comment-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 6px;
        
        .comment-username {
          font-size: 15px;
          font-weight: 600;
          color: #333;
        }
        
        .comment-time {
          font-size: 12px;
          color: #999;
        }
      }
      
      .comment-content {
        font-size: 16px;
        color: #333;
        line-height: 1.5;
        margin-bottom: 8px;
        display: block;
      }
      
      .comment-actions {
        display: flex;
        justify-content: space-between;
        align-items: center;
        
        .action-left, .action-right {
          display: flex;
          align-items: center;
          gap: 16px;
        }
        
        .like-action, .reply-action, .delete-action {
          font-size: 13px;
          color: #999;
          display: flex;
          align-items: center;
          gap: 4px;
          cursor: pointer;
          
          &:active {
            color: #ffa500;
          }
        }
        
        // 专门为删除按钮设置样式
        .delete-action {
          color: #ff6b6b;
          
          &:active {
            color: #ff2442;
          }
        }
      }
      
      .reply-list {
        margin-top: 12px;
        background: #f8f8f8;
        border-radius: 12px;
        padding: 12px;
        display: flex;
        flex-direction: column;
        gap: 10px;
      }
      
      .reply-item {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        
        .reply-content {
          flex: 1;
          
          .reply-username {
            font-size: 14px;
            font-weight: 600;
            color: #333;
          }
          
          .reply-text {
            font-size: 14px;
            color: #666;
            line-height: 1.4;
          }
        }
        
        .reply-actions {
          display: flex;
          align-items: center;
          gap: 8px;
          
          .reply-like, .delete-reply {
            font-size: 12px;
            color: #ccc;
            display: flex;
            align-items: center;
            gap: 2px;
            cursor: pointer;
            flex-shrink: 0;
          }
          
          .delete-reply {
            color: #ff6b6b;
            
            &:active {
              color: #ff2442;
            }
          }
        }
      }
      
      .reply-input-container {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-top: 12px;
        background: #f8f8f8;
        border-radius: 18px;
        padding: 8px 12px;
        
        .reply-input {
          flex: 1;
          background: transparent;
          border: none;
          outline: none;
          font-size: 14px;
          color: #333;
        }
        
        .reply-send {
          font-size: 14px;
          color: #ffa500;
          font-weight: 500;
          cursor: pointer;
        }
      }
    }

    .load-more {
      text-align: center;
      padding: 30px 0 20px;
      
      .load-text {
        font-size: 13px;
        color: #ccc;
      }
    }
  }

  // 底部安全区域
  .bottom-safe-area {
    height: constant(safe-area-inset-bottom);
    height: env(safe-area-inset-bottom);
    background: #fafafa;
  }
}

// 响应式适配
@media (max-width: 375px) {
  .detail-page {
    .nav-bar {
      padding: 8px 12px;
    }
    
    .image-carousel {
      height: 70vh;
    }
    
    .content-section {
      padding: 12px;
      
      // 坐标响应式样式
      .location-coordinate {
        font-size: 13px;
        padding: 12px 14px;
        margin-bottom: 12px;
      }
    }
    
    .comment-section {
      padding: 0 12px 30px;
    }
    
    .simple-actions {
      right: 12px;
      bottom: 100px;
      
      .action-item {
        padding: 10px;
        
        .action-text {
          font-size: 11px;
        }
      }
    }
  }
}

// 暗色模式适配
@media (prefers-color-scheme: dark) {
  .detail-page {
    background: #000;
    color: #fff;
    
    .nav-bar.nav-scroll {
      background: rgba(0, 0, 0, 0.95);
    }
    
    .content-section {
      .note-title, .desc-text {
        color: #fff;
      }
      
      // 坐标暗色模式样式
      .location-coordinate {
        background: #1a3a36;
        border-color: #2d7d74;
        
        .coordinate-text {
          color: #88e6d8;
        }
      }
    }
    
    .comment-section {
      background: #111;
    }
    
    .simple-actions {
      .action-item {
        background: rgba(0, 0, 0, 0.8);
        
        .action-text {
          color: #fff;
        }
      }
    }
  }
}
</style>