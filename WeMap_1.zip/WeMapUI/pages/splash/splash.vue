<template>
  <view class="splash-container">
    <!-- 动画元素 -->
    <view class="duck-animation">
      <image src="/static/images/启动.png" mode="widthFix" class="duck"></image>
    </view>
    <view class="slogan">世界那么大</view>
  </view>
</template>

<script setup>
import { onMounted } from 'vue';

onMounted(() => {
  // 3秒后跳转到登录页
  setTimeout(() => {
    uni.redirectTo({
      url: '/pages/login/login'
    });
  }, 3000);
});
</script>

<style lang="scss">
.splash-container {
  width: 100%;
  height: 100vh;
  background: linear-gradient(135deg, #fff9e6 0%, #fff0cc 100%);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;

  .duck-animation {
    .duck {
      width: 240rpx;
      animation: float 2s ease-in-out infinite;
    }
  }

  .slogan {
    margin-top: 80rpx;
    font-size: 48rpx;
    color: #ff8f00;
    font-weight: bold;
    animation: fadeIn 1.5s ease-out;
  }
}

// 浮动动画
@keyframes float {
  0%, 100% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(-20rpx);
  }
}

// 淡入动画
@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(20rpx);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
</style>