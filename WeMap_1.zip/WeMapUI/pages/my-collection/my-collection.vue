<template>
  <view class="collection-page">
    <!-- 顶部导航栏 -->
    <view class="nav-bar">
      <view class="nav-back" @click="goBack">
        <uni-icons type="left" size="28" color="#333"></uni-icons>
      </view>
      <view class="nav-title">我的收藏</view>
      <view class="nav-actions">
        <uni-icons type="more-dot" size="28" color="#333" @click="showMoreActions"></uni-icons>
      </view>
    </view>
    
    <!-- 统计信息 -->
    <view class="stats-section" v-if="notes.length > 0">
      <view class="stat-item">
        <text class="stat-number">{{ notes.length }}</text>
        <text class="stat-label">收藏笔记</text>
      </view>
      <view class="stat-divider"></view>
      <view class="stat-item">
        <text class="stat-number">{{ totalViews }}</text>
        <text class="stat-label">累计浏览</text>
      </view>
    </view>
    
    <!-- 空状态显示 -->
    <view class="empty-state" v-if="notes.length === 0 && !loading">
      <view class="empty-icon">
        <uni-icons type="star" size="80" color="#e0e0e0"></uni-icons>
      </view>
      <view class="empty-text">暂无收藏的笔记</view>
      <view class="empty-desc">收藏的笔记会显示在这里哦~</view>
      <view class="empty-action" @click="goToDiscover">
        <text>去发现精彩内容</text>
      </view>
    </view>
    
    <!-- 加载状态 -->
    <view class="loading-state" v-if="loading && notes.length === 0">
      <view class="loading-spinner">
        <uni-icons type="spinner-cycle" size="40" color="#ff6b6b"></uni-icons>
      </view>
      <view class="loading-text">加载中...</view>
    </view>
    
    <!-- 笔记列表 -->
    <view class="note-list" v-else-if="notes.length > 0">
      <view 
        class="note-item" 
        v-for="(note, index) in notes" 
        :key="note.id" 
        @click="goToNoteDetail(note)"
      >
        <view class="note-header">
          <image :src="note.cover" mode="aspectFill" class="note-cover"></image>
          <view class="note-overlay">
            <view class="note-category" v-if="note.category">{{ note.category }}</view>
          </view>
        </view>
        
        <view class="note-content">
          <view class="note-title">{{ note.title }}</view>
          <view class="note-desc">{{ note.desc }}</view>
          
          <view class="note-meta">
            <view class="meta-left">
              <view class="author-info">
                <image :src="note.authorAvatar || '/static/images/default-avatar.jpg'" class="author-avatar" mode="aspectFill"></image>
                <text class="author-name">{{ note.author }}</text>
              </view>
              <text class="note-time">{{ formatTime(note.time) }}</text>
            </view>
            
            <view class="meta-right">
              <view class="note-stats">
                <view class="stat">
                  <uni-icons type="heart" size="14" color="#999"></uni-icons>
                  <text>{{ formatNum(note.likes) }}</text>
                </view>
                <view class="stat">
                  <uni-icons type="eye" size="14" color="#999"></uni-icons>
                  <text>{{ formatNum(note.views) }}</text>
                </view>
              </view>
            </view>
          </view>
        </view>
        
        <view class="note-actions">
          <view class="action-btn cancel-btn" @click.stop="cancelCollection(note.id, index)">
            <uni-icons type="star-filled" size="18" color="#ff4d4f"></uni-icons>
            <text>取消收藏</text>
          </view>
          <view class="action-btn share-btn" @click.stop="shareNote(note)">
            <uni-icons type="share" size="18" color="#666"></uni-icons>
            <text>分享</text>
          </view>
        </view>
      </view>
    </view>
    
    <!-- 加载更多 -->
    <view class="load-more" v-if="notes.length > 0 && hasMore">
      <text class="load-text" @click="loadMore">加载更多</text>
    </view>
    
    <!-- 底部安全区域 -->
    <view class="bottom-safe-area"></view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      notes: [],
      loading: false,
      hasMore: true,
      page: 1,
      pageSize: 10
    }
  },
  
  computed: {
    totalViews() {
      return this.notes.reduce((total, note) => total + (note.views || 0), 0);
    }
  },
  
  onLoad() {
    this.loadCollectionNotes();
    // 监听数据更新事件
    uni.$on('updateCollectionNotes', this.loadCollectionNotes);
  },
  
  onUnload() {
    uni.$off('updateCollectionNotes', this.loadCollectionNotes);
  },
  
  methods: {
    async loadCollectionNotes() {
      this.loading = true;
      
      try {
        // TODO: 需要接口 - 获取用户收藏列表
        // 接口地址：/api/collection/list
        // 请求方法：GET
        // 参数：{ page: this.page, pageSize: this.pageSize }
        // 返回数据格式：{ code: 200, data: { list: [], total: 0, hasMore: boolean } }
        
        // 模拟网络请求
        await new Promise(resolve => setTimeout(resolve, 800));
        
        const cacheNotes = uni.getStorageSync('collectionNotes');
        if (cacheNotes && cacheNotes.length > 0) {
          this.notes = cacheNotes;
        } else {
          // 初始模拟数据 - 实际应从接口获取
          this.notes = [
            {
              id: 1,
              title: 'Vue3组合式API完全指南',
              desc: '详细介绍Vue3组合式API的使用方法和最佳实践，包括setup、ref、reactive等核心API...',
              cover: '/static/images/note1.jpg',
              time: '2025-10-15',
              author: '前端技术栈',
              authorAvatar: '/static/images/avatar1.jpg',
              category: '技术',
              likes: 128,
              views: 1560,
              collects: 96,
              content: '# Vue3组合式API完全指南\n\nVue3的组合式API是一种全新的代码组织方式...',
              tags: ['Vue3', '前端', 'JavaScript']
            },
            {
              id: 2,
              title: 'UniApp跨端开发技巧',
              desc: '总结UniApp开发中的常见问题和解决方案，包括适配、性能优化、原生插件使用...',
              cover: '/static/images/note2.jpg',
              time: '2025-09-28',
              author: '跨端开发师',
              authorAvatar: '/static/images/avatar2.jpg',
              category: '技术',
              likes: 98,
              views: 1240,
              collects: 76,
              content: '# UniApp跨端开发技巧\n\nUniApp是一个使用Vue.js开发所有前端应用的框架...',
              tags: ['UniApp', '跨端', '移动开发']
            },
            {
              id: 3,
              title: 'SCSS样式开发规范',
              desc: '分享SCSS的变量、混合、嵌套等高级特性的使用规范，提高样式开发效率...',
              cover: '/static/images/note3.jpg',
              time: '2025-09-10',
              author: '样式工程师',
              authorAvatar: '/static/images/avatar3.jpg',
              category: '技术',
              likes: 76,
              views: 980,
              collects: 58,
              content: '# SCSS样式开发规范\n\nSCSS是CSS的预处理器，提供了变量、嵌套、混合等功能...',
              tags: ['SCSS', 'CSS', '前端']
            }
          ];
          uni.setStorageSync('collectionNotes', this.notes);
        }
        
        this.loading = false;
        this.hasMore = this.notes.length >= this.pageSize;
      } catch (error) {
        console.error('加载收藏笔记失败:', error);
        this.loading = false;
        uni.showToast({
          title: '加载失败',
          icon: 'none'
        });
      }
    },
    
    async loadMore() {
      if (this.loading || !this.hasMore) return;
      
      this.page += 1;
      this.loading = true;
      
      try {
        // TODO: 需要接口 - 加载更多收藏笔记
        // 接口地址：/api/collection/list
        // 请求方法：GET
        // 参数：{ page: this.page, pageSize: this.pageSize }
        
        // 模拟网络请求
        await new Promise(resolve => setTimeout(resolve, 800));
        
        // 模拟更多数据
        const moreNotes = [
          {
            id: 4,
            title: 'JavaScript设计模式实践',
            desc: '深入讲解JavaScript中常用的设计模式及其在实际项目中的应用场景...',
            cover: '/static/images/note4.jpg',
            time: '2025-08-25',
            author: 'JS专家',
            authorAvatar: '/static/images/avatar4.jpg',
            category: '技术',
            likes: 64,
            views: 870,
            collects: 42,
            content: '# JavaScript设计模式实践\n\n设计模式是解决特定问题的可重用方案...',
            tags: ['JavaScript', '设计模式', '编程']
          }
        ];
        
        this.notes = [...this.notes, ...moreNotes];
        uni.setStorageSync('collectionNotes', this.notes);
        
        this.loading = false;
        this.hasMore = false; // 模拟没有更多数据
        
        uni.showToast({
          title: '没有更多数据了',
          icon: 'none'
        });
      } catch (error) {
        console.error('加载更多失败:', error);
        this.loading = false;
        uni.showToast({
          title: '加载失败',
          icon: 'none'
        });
      }
    },
    
    goBack() {
      uni.navigateBack();
    },
    
    goToDiscover() {
      uni.switchTab({
        url: '/pages/index/index'
      });
    },
    
    goToNoteDetail(note) {
      // 跳转到笔记详情页，传递完整的笔记对象
      uni.navigateTo({
        url: `/pages/detail/detail?note=${encodeURIComponent(JSON.stringify(note))}`
      });
    },
    
    async cancelCollection(noteId, index) {
      uni.showModal({
        title: '取消收藏',
        content: '确定要取消收藏这篇笔记吗？',
        cancelText: '再想想',
        confirmText: '确定取消',
        confirmColor: '#ff4d4f',
        success: async (res) => {
          if (res.confirm) {
            try {
              // TODO: 需要接口 - 取消收藏笔记
              // 接口地址：/api/collection/cancel
              // 请求方法：POST
              // 参数：{ noteId: noteId }
              // 返回数据格式：{ code: 200, message: '取消收藏成功' }
              
              // 模拟网络请求
              await new Promise(resolve => setTimeout(resolve, 500));
              
              const removedNote = this.notes.splice(index, 1)[0];
              
              // 更新本地存储
              uni.setStorageSync('collectionNotes', this.notes);
              
              // 更新全局收藏状态
              let collectedNotes = uni.getStorageSync('collectedNotes') || [];
              collectedNotes = collectedNotes.filter(id => id !== removedNote.id);
              uni.setStorageSync('collectedNotes', collectedNotes);
              
              // 通知其他页面更新
              uni.$emit('updateNoteCounts');
              
              uni.showToast({
                title: '已取消收藏',
                icon: 'success',
                duration: 1500
              });
              
              // 如果列表为空，显示空状态
              if (this.notes.length === 0) {
                setTimeout(() => {
                  uni.showModal({
                    title: '提示',
                    content: '收藏列表已空，去发现更多精彩内容吧！',
                    showCancel: false,
                    confirmText: '去发现',
                    success: (res) => {
                      if (res.confirm) {
                        this.goToDiscover();
                      }
                    }
                  });
                }, 1000);
              }
            } catch (error) {
              console.error('取消收藏失败:', error);
              uni.showToast({
                title: '操作失败',
                icon: 'none'
              });
            }
          }
        }
      });
    },
    
    shareNote(note) {
      uni.showActionSheet({
        itemList: ['分享给好友', '分享到朋友圈', '复制链接'],
        success: async (res) => {
          const tapIndex = res.tapIndex;
          
          try {
            // TODO: 需要接口 - 获取笔记分享链接（如果需要动态生成）
            // 接口地址：/api/note/share-url
            // 请求方法：GET
            // 参数：{ noteId: note.id }
            
            switch (tapIndex) {
              case 0:
                uni.share({
                  provider: 'weixin',
                  scene: 'WXSceneSession',
                  type: 0,
                  href: `https://example.com/note/${note.id}`,
                  title: note.title,
                  summary: note.desc,
                  imageUrl: note.cover,
                  success: () => {
                    uni.showToast({ title: '已分享给好友', icon: 'success' });
                  }
                });
                break;
              case 1:
                uni.share({
                  provider: 'weixin',
                  scene: 'WXSceneTimeline',
                  type: 0,
                  href: `https://example.com/note/${note.id}`,
                  title: note.title,
                  summary: note.desc,
                  imageUrl: note.cover,
                  success: () => {
                    uni.showToast({ title: '已分享到朋友圈', icon: 'success' });
                  }
                });
                break;
              case 2:
                uni.setClipboardData({
                  data: `https://example.com/note/${note.id}`,
                  success: () => {
                    uni.showToast({ title: '链接已复制', icon: 'success' });
                  }
                });
                break;
            }
          } catch (error) {
            console.error('分享失败:', error);
            uni.showToast({
              title: '分享失败',
              icon: 'none'
            });
          }
        }
      });
    },
    
    showMoreActions() {
      uni.showActionSheet({
        itemList: ['批量管理', '清空收藏', '导出数据'],
        success: (res) => {
          const tapIndex = res.tapIndex;
          switch (tapIndex) {
            case 0:
              uni.showToast({ title: '批量管理功能开发中', icon: 'none' });
              break;
            case 1:
              this.clearAllCollections();
              break;
            case 2:
              // TODO: 需要接口 - 导出收藏数据
              // 接口地址：/api/collection/export
              // 请求方法：GET
              // 返回数据格式：文件流或下载链接
              uni.showToast({ title: '导出功能开发中', icon: 'none' });
              break;
          }
        }
      });
    },
    
    async clearAllCollections() {
      if (this.notes.length === 0) {
        uni.showToast({ title: '收藏列表已为空', icon: 'none' });
        return;
      }
      
      uni.showModal({
        title: '清空收藏',
        content: `确定要清空所有收藏吗？共${this.notes.length}篇笔记`,
        cancelText: '取消',
        confirmText: '确定清空',
        confirmColor: '#ff4d4f',
        success: async (res) => {
          if (res.confirm) {
            try {
              // TODO: 需要接口 - 清空所有收藏
              // 接口地址：/api/collection/clear-all
              // 请求方法：POST
              // 参数：无
              // 返回数据格式：{ code: 200, message: '清空成功' }
              
              // 模拟网络请求
              await new Promise(resolve => setTimeout(resolve, 500));
              
              this.notes = [];
              uni.setStorageSync('collectionNotes', []);
              uni.setStorageSync('collectedNotes', []);
              uni.$emit('updateNoteCounts');
              
              uni.showToast({
                title: '收藏已清空',
                icon: 'success',
                duration: 2000
              });
            } catch (error) {
              console.error('清空收藏失败:', error);
              uni.showToast({
                title: '操作失败',
                icon: 'none'
              });
            }
          }
        }
      });
    },
    
    formatNum(num) {
      // 修复：处理 undefined 和 null 的情况
      if (num === undefined || num === null) {
        return '0';
      }
      
      // 确保 num 是数字类型
      const numberValue = Number(num);
      
      if (isNaN(numberValue)) {
        return '0';
      }
      
      if (numberValue >= 10000) {
        return (numberValue / 10000).toFixed(1) + '万';
      }
      
      return numberValue.toString();
    },
    
    formatTime(timeStr) {
      // 修复：处理 undefined 和 null 的情况
      if (!timeStr) {
        return '未知时间';
      }
      
      try {
        const date = new Date(timeStr);
        if (isNaN(date.getTime())) {
          return '未知时间';
        }
        
        const now = new Date();
        const diff = now.getTime() - date.getTime();
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        
        if (days === 0) {
          return '今天';
        } else if (days === 1) {
          return '昨天';
        } else if (days < 7) {
          return `${days}天前`;
        } else if (days < 30) {
          return `${Math.floor(days / 7)}周前`;
        } else {
          return `${date.getMonth() + 1}月${date.getDate()}日`;
        }
      } catch (error) {
        console.error('时间格式化错误:', error);
        return '未知时间';
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.collection-page {
  min-height: 100vh;
  background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
  
  // 导航栏
  .nav-bar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 88rpx;
    padding: 0 30rpx;
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter: blur(10px);
    border-bottom: 1px solid rgba(0, 0, 0, 0.1);
    
    .nav-back, .nav-actions {
      width: 60rpx;
      height: 60rpx;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      background: rgba(0, 0, 0, 0.05);
    }
    
    .nav-title {
      font-size: 36rpx;
      font-weight: 600;
      color: #333;
    }
  }
  
  // 统计信息
  .stats-section {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 40rpx 30rpx;
    background: rgba(255, 255, 255, 0.8);
    margin: 20rpx;
    border-radius: 20rpx;
    backdrop-filter: blur(10px);
    
    .stat-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      flex: 1;
      
      .stat-number {
        font-size: 48rpx;
        font-weight: 700;
        color: #ff6b6b;
        margin-bottom: 8rpx;
      }
      
      .stat-label {
        font-size: 24rpx;
        color: #666;
      }
    }
    
    .stat-divider {
      width: 1px;
      height: 60rpx;
      background: linear-gradient(to bottom, transparent, #ddd, transparent);
      margin: 0 40rpx;
    }
  }
  
  // 空状态
  .empty-state {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 200rpx 60rpx;
    
    .empty-icon {
      margin-bottom: 40rpx;
      opacity: 0.6;
    }
    
    .empty-text {
      font-size: 32rpx;
      color: #666;
      margin-bottom: 20rpx;
      font-weight: 500;
    }
    
    .empty-desc {
      font-size: 28rpx;
      color: #999;
      margin-bottom: 60rpx;
      text-align: center;
      line-height: 1.6;
    }
    
    .empty-action {
      padding: 20rpx 40rpx;
      background: linear-gradient(135deg, #ff6b6b, #ffa500);
      border-radius: 50rpx;
      color: white;
      font-size: 28rpx;
      font-weight: 500;
      box-shadow: 0 8rpx 20rpx rgba(255, 107, 107, 0.3);
      
      &:active {
        transform: scale(0.95);
        box-shadow: 0 4rpx 10rpx rgba(255, 107, 107, 0.3);
      }
    }
  }
  
  // 加载状态
  .loading-state {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 200rpx 60rpx;
    
    .loading-spinner {
      margin-bottom: 30rpx;
      animation: spin 1s linear infinite;
    }
    
    .loading-text {
      font-size: 28rpx;
      color: #999;
    }
    
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
  }
  
  // 笔记列表
  .note-list {
    padding: 20rpx;
    display: grid;
    gap: 24rpx;
  }
  
  .note-item {
    background: rgba(255, 255, 255, 0.9);
    border-radius: 24rpx;
    overflow: hidden;
    backdrop-filter: blur(10px);
    box-shadow: 0 8rpx 30rpx rgba(0, 0, 0, 0.08);
    transition: all 0.3s ease;
    
    &:active {
      transform: scale(0.98);
      box-shadow: 0 4rpx 15rpx rgba(0, 0, 0, 0.1);
    }
    
    .note-header {
      position: relative;
      height: 300rpx;
      
      .note-cover {
        width: 100%;
        height: 100%;
      }
      
      .note-overlay {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: linear-gradient(to bottom, transparent 60%, rgba(0, 0, 0, 0.3));
        display: flex;
        align-items: flex-end;
        justify-content: flex-start;
        padding: 20rpx;
        
        .note-category {
          background: rgba(255, 255, 255, 0.9);
          padding: 8rpx 16rpx;
          border-radius: 20rpx;
          font-size: 22rpx;
          color: #ff6b6b;
          font-weight: 500;
        }
      }
    }
    
    .note-content {
      padding: 30rpx;
      
      .note-title {
        font-size: 34rpx;
        font-weight: 600;
        color: #333;
        margin-bottom: 20rpx;
        line-height: 1.4;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
      }
      
      .note-desc {
        font-size: 28rpx;
        color: #666;
        line-height: 1.6;
        margin-bottom: 24rpx;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
      }
      
      .note-meta {
        display: flex;
        justify-content: space-between;
        align-items: center;
        
        .meta-left {
          display: flex;
          align-items: center;
          gap: 20rpx;
          
          .author-info {
            display: flex;
            align-items: center;
            gap: 12rpx;
            
            .author-avatar {
              width: 48rpx;
              height: 48rpx;
              border-radius: 50%;
              border: 2rpx solid #f0f0f0;
            }
            
            .author-name {
              font-size: 24rpx;
              color: #666;
            }
          }
          
          .note-time {
            font-size: 22rpx;
            color: #999;
          }
        }
        
        .meta-right {
          .note-stats {
            display: flex;
            align-items: center;
            gap: 20rpx;
            
            .stat {
              display: flex;
              align-items: center;
              gap: 6rpx;
              font-size: 22rpx;
              color: #999;
            }
          }
        }
      }
    }
    
    .note-actions {
      display: flex;
      border-top: 1rpx solid #f0f0f0;
      
      .action-btn {
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 12rpx;
        padding: 24rpx;
        font-size: 26rpx;
        font-weight: 500;
        transition: all 0.3s ease;
        
        &.cancel-btn {
          color: #ff4d4f;
          border-right: 1rpx solid #f0f0f0;
          
          &:active {
            background: rgba(255, 77, 79, 0.1);
          }
        }
        
        &.share-btn {
          color: #666;
          
          &:active {
            background: rgba(0, 0, 0, 0.05);
          }
        }
      }
    }
  }
  
  // 加载更多
  .load-more {
    text-align: center;
    padding: 40rpx;
    
    .load-text {
      display: inline-block;
      padding: 20rpx 40rpx;
      background: rgba(255, 255, 255, 0.8);
      border-radius: 50rpx;
      font-size: 28rpx;
      color: #666;
      backdrop-filter: blur(10px);
      
      &:active {
        background: rgba(255, 255, 255, 0.9);
      }
    }
  }
  
  // 底部安全区域
  .bottom-safe-area {
    height: constant(safe-area-inset-bottom);
    height: env(safe-area-inset-bottom);
    background: transparent;
  }
}

// 暗色模式适配
@media (prefers-color-scheme: dark) {
  .collection-page {
    background: linear-gradient(135deg, #2c3e50 0%, #3498db 100%);
    
    .nav-bar {
      background: rgba(0, 0, 0, 0.8);
      
      .nav-back, .nav-actions {
        background: rgba(255, 255, 255, 0.1);
      }
      
      .nav-title {
        color: #fff;
      }
    }
    
    .stats-section {
      background: rgba(0, 0, 0, 0.5);
      
      .stat-label {
        color: #ccc;
      }
    }
    
    .empty-state {
      .empty-text {
        color: #ccc;
      }
      
      .empty-desc {
        color: #999;
      }
    }
    
    .note-item {
      background: rgba(0, 0, 0, 0.5);
      
      .note-content {
        .note-title {
          color: #fff;
        }
        
        .note-desc {
          color: #ccc;
        }
        
        .note-meta {
          .meta-left {
            .author-name {
              color: #ccc;
            }
            
            .note-time {
              color: #999;
            }
          }
        }
      }
      
      .note-actions {
        border-top-color: #333;
        
        .action-btn {
          &.cancel-btn:active {
            background: rgba(255, 77, 79, 0.2);
          }
          
          &.share-btn:active {
            background: rgba(255, 255, 255, 0.1);
          }
        }
      }
    }
    
    .load-more {
      .load-text {
        background: rgba(0, 0, 0, 0.5);
        color: #ccc;
        
        &:active {
          background: rgba(0, 0, 0, 0.6);
        }
      }
    }
  }
}
</style>