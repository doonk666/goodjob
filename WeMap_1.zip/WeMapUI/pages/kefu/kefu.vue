<template>
  <view class="kefu-container">
    <view class="nav-bar">
      <uni-icons type="left" size="28" color="#333" @click="goBack"></uni-icons>
      <view class="nav-title">联系客服</view>
      <view class="empty"></view>
    </view>
    <view class="kefu-info">
      <view class="contact-item">
        <view class="item-icon">
          <uni-icons type="phone-filled" size="32" color="#007AFF"></uni-icons>
        </view>
        <view class="item-content">
          <view class="item-label">客服电话</view>
          <view class="item-value" @click="copyPhone">138-8888-8888</view>
        </view>
        <uni-icons type="copy" size="24" color="#888" @click="copyPhone"></uni-icons>
      </view>
      <view class="contact-item qrcode-item">
        <view class="item-icon">
          <uni-icons type="weixin-filled" size="32" color="#07C160"></uni-icons>
        </view>
        <view class="item-content">
          <view class="item-label">微信客服</view>
          <view class="qrcode-box">
            <image src="/static/images/二维码.jpg" mode="widthFix"></image>
            <view class="qrcode-tip">扫码添加客服微信</view>
          </view>
        </view>
      </view>
    </view>
	</view>
  </template>

  <script setup>
  import { useRouter } from 'vue-router';
  const router = useRouter();
  const goBack = () => {
    router.back();
  };
  const copyPhone = () => {
    const phone = '13888888888';
    uni.setClipboardData({
      data: phone,
      success: () => {
        uni.showToast({ title: '手机号已复制', icon: 'success', duration: 1500 });
      },
      fail: () => {
        uni.showToast({ title: '复制失败', icon: 'none', duration: 1500 });
      }
    });
  };
  </script>
  <style lang="scss">
  .kefu-container {
    background-color: #f5f5f5;
    min-height: 100vh;
    .nav-bar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 100rpx;
      padding: 0 30rpx;
      background-color: #fff;
      box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.05);
      .nav-title {
        font-size: 32rpx;
        color: #333;
        font-weight: 500;
      }
      .empty {
        width: 28rpx;
      }
    }
    .kefu-info {
      margin: 30rpx;
      background-color: #fff;
      border-radius: 16rpx;
      padding: 40rpx 30rpx;
      box-shadow: 0 0 30rpx rgba(0, 0, 0, 0.03);
    }
    .contact-item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding-bottom: 40rpx;
      border-bottom: 1px solid #eee;
      &:last-child {
        border-bottom: none;
        padding-bottom: 0;
      }
      .item-icon {
        margin-right: 24rpx;
      }
      .item-content {
        flex: 1;
        .item-label {
          font-size: 28rpx;
          color: #888;
          margin-bottom: 8rpx;
        }
        .item-value {
          font-size: 32rpx;
          color: #333;
          font-weight: 500;
        }
      }
    }
    .qrcode-item {
      align-items: flex-start;
      .qrcode-box {
        margin-top: 10rpx;
        image {
          width: 240rpx;
          height: auto;
          border-radius: 8rpx;
        }

        .qrcode-tip {
          font-size: 24rpx;
          color: #aaa;
          margin-top: 12rpx;
          text-align: center;
        }
      }
    }
  }
  </style>