<template>
	<view>
		公共标题
	</view>
</template>

<script>
	export default {
		name:"commom-title",
		data() {
			return {
				
			};
		}
	}
</script>

<style>

</style>